# Entrega Motor / Lab 1.0.0 · vista mecánica · 2 de octubre de 2026

Simulador independiente de motor monofásico 5 HP, acoplamiento y bomba de agua
limpia. Todos los datos y efectos son simulados. El interior es ilustrativo.

## Abrir esta entrega en Windows

1. Extrae TODO el ZIP en una carpeta local; no ejecutes archivos dentro del ZIP.
2. Necesitas Python 3.12 disponible para tu usuario. No se instala automáticamente.
3. Haz doble clic en `iniciar.bat`. Crea `.venv` aislado sin descargas ni paquetes
   de terceros y abre http://127.0.0.1:8766. Otro puerto: `iniciar.bat --port 8767`.
4. Pulsa **Acercar motor**, selecciona un componente y prueba los escenarios.
   La salida a otros programas permanece desactivada hasta que la actives.
5. Usa `cerrar.bat` para detener y guardar. Cerrar la pestaña no detiene el servicio.

Los accesos `.lnk` y los lanzadores de la carpeta del proyecto original no forman
parte de este ZIP: usa los `.bat` incluidos aquí. Datos por defecto en
`%LOCALAPPDATA%\MotorPumpTwin`, fuera de la entrega. Al instalar en el mismo PC
conserva la base existente; no ejecutes dos instancias sobre la misma carpeta de
datos. Para pruebas separadas usa `iniciar.bat --port 8767 --data-dir "D:\Ensayo"`.

## Contenido editable

`twin/`: modelo, contrato, reloj, SQLite, transporte, servidor, lanzador y web.
`examples/`: consulta Python y receptor local voluntario.
`tests/`: pruebas con bases temporales; `probar.bat` ejecuta el núcleo.
`API.md` y `MODELO.md`: contrato, física reducida y límites.
`VERIFICACION.md`: verificaciones históricas ejecutadas en Windows/Edge.
`README_DESARROLLO.md`: guía completa y contexto de la carpeta original.
`ENTREGA.json`: inventario y SHA-256 de los archivos de esta distribución.

Los ensayos de navegador requieren Node, Playwright y Edge como herramientas
opcionales de desarrollo. No son dependencias de uso del simulador. Configura
`TWIN_PLAYWRIGHT` si Playwright no está disponible como módulo habitual.

Este archivo es una distribución de la carpeta principal de desarrollo, no una
segunda implementación mantenida. No incluye datos, entornos ni el software
neiron. No hay hardware conectado, IA ni diagnóstico validado.
