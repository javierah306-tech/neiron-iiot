"""Cliente independiente. Ejecute con Python 3.12; solo biblioteca estándar."""
import argparse
import json
import time
from urllib.request import build_opener, ProxyHandler
from urllib.error import HTTPError, URLError

parser=argparse.ArgumentParser()
parser.add_argument("--port",type=int,default=8766)
args=parser.parse_args()
opener=build_opener(ProxyHandler({}))
previous=None
try:
    while True:
        try:
            with opener.open(f"http://127.0.0.1:{args.port}/api/latest",timeout=3) as response:
                p=json.load(response)
            identity=(p["instance_id"],p["sequence"])
            if identity!=previous:
                print(p["acquired_at"],p["source"],p["temperature"],p["vibration"],flush=True)
                previous=identity
        except HTTPError as error:
            print("Sin lectura actual:",error.code,flush=True)
        except (URLError,OSError):
            print("Simulador no disponible.",flush=True)
        time.sleep(1)
except KeyboardInterrupt:
    print("Cliente cerrado.")
