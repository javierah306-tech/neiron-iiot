"""Receptor POST de ejemplo reutilizable, sin importar el simulador ni neiron.

Acepta paquetes recientes, rechaza inválidos/duplicados/fuera de orden y agrega received_at.
Usar --data-dir para aislar las pruebas. No transforma el origen simulado en real.
"""
import argparse
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
import os
from pathlib import Path
import sqlite3
from threading import RLock

class Receiver(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,address,directory):
        super().__init__(address,Handler)
        Path(directory).mkdir(parents=True,exist_ok=True)
        self.lock=RLock()
        self.db=sqlite3.connect(Path(directory)/"receiver.sqlite3",check_same_thread=False)
        self.db.executescript("CREATE TABLE IF NOT EXISTS received(instance_id TEXT, sequence INTEGER, acquired_at TEXT, received_at TEXT, packet TEXT, PRIMARY KEY(instance_id,sequence));")
        self.db.commit()

def validate(p):
    if not isinstance(p,dict) or p.get("schema")!="motor-pump-twin.telemetry" or type(p.get("schema_version")) is not int or p["schema_version"]!=1 or p.get("source")!="simulated":
        raise ValueError("Contrato u origen desconocido.")
    if not isinstance(p.get("instance_id"),str) or not 1<=len(p["instance_id"])<=80 or type(p.get("sequence")) is not int or not 1<=p["sequence"]<2**63:
        raise ValueError("Identidad o secuencia inválida.")
    dt=datetime.fromisoformat(p["acquired_at"].replace("Z","+00:00"))
    if dt.tzinfo is None or not -5<=(datetime.now(timezone.utc)-dt).total_seconds()<=5:
        raise ValueError("Paquete antiguo, futuro o sin zona horaria.")
    for key,unit,low,high in (("temperature","degC",-55,125),("vibration","m/s2",0,200)):
        item=p[key];value=item["value"]
        if item["unit"]!=unit or type(value) not in (int,float) or not math.isfinite(value) or not low<=value<=high:
            raise ValueError("Canal inválido.")
    if p.get("quality") not in {"synthetic","saturated"}:
        raise ValueError("Calidad inválida.")
    return dt.astimezone(timezone.utc).isoformat(timespec="milliseconds")

class Handler(BaseHTTPRequestHandler):
    def response(self,code,data):
        raw=json.dumps(data,ensure_ascii=False).encode("utf-8")
        self.send_response(code);self.send_header("Content-Type","application/json; charset=utf-8");self.send_header("Content-Length",str(len(raw)));self.end_headers();self.wfile.write(raw)
    def do_GET(self):
        if self.path!="/status":self.response(404,{"error":"Use POST /telemetry o GET /status."});return
        with self.server.lock:
            count=self.server.db.execute("SELECT COUNT(*) FROM received").fetchone()[0]
        self.response(200,{"accepted":count,"source":"simulated"})
    def do_POST(self):
        if self.path!="/telemetry":self.response(404,{"error":"Use POST /telemetry."});return
        try:
            if self.client_address[0]!="127.0.0.1":raise ValueError("Solo se permite bucle local.")
            length=int(self.headers.get("Content-Length","0"))
            if not 0<length<=32768:raise ValueError("Cuerpo JSON de hasta 32 KB requerido.")
            p=json.loads(self.rfile.read(length),parse_constant=lambda x:(_ for _ in ()).throw(ValueError("Número no finito.")))
            acquired=validate(p)
            received=datetime.now(timezone.utc).isoformat(timespec="milliseconds")
            with self.server.lock:
                last=self.server.db.execute("SELECT sequence,acquired_at FROM received WHERE instance_id=? ORDER BY sequence DESC LIMIT 1",(p["instance_id"],)).fetchone()
                if last and (p["sequence"]<=last[0] or acquired<last[1]):
                    self.response(409,{"error":"Duplicado o fuera de orden; no guardado."});return
                self.server.db.execute("INSERT INTO received VALUES(?,?,?,?,?)",(p["instance_id"],p["sequence"],acquired,received,json.dumps(p,ensure_ascii=False)))
                self.server.db.commit()
            self.response(201,{"accepted":True,"sequence":p["sequence"],"received_at":received})
        except (ValueError,TypeError,KeyError,OverflowError) as error:
            self.response(400,{"error":str(error)})

if __name__=="__main__":
    parser=argparse.ArgumentParser(description="Receptor local de prueba; actívelo manualmente.")
    parser.add_argument("--port",type=int,default=9000)
    parser.add_argument("--data-dir",type=Path,default=Path(os.environ.get("LOCALAPPDATA",str(Path.home())))/"MotorPumpTwin"/"receiver-demo")
    args=parser.parse_args()
    server=Receiver(("127.0.0.1",args.port),args.data_dir)
    print(f"Receptor de prueba: http://127.0.0.1:{args.port}/telemetry\nDatos: {args.data_dir}\nCtrl+C para cerrar.",flush=True)
    try:server.serve_forever(poll_interval=.25)
    except KeyboardInterrupt:pass
    finally:server.server_close();server.db.close()
