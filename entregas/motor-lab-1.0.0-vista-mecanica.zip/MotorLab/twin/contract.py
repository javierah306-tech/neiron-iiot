"""Contrato genérico independiente de un receptor o dispositivo físico."""
from datetime import datetime, timezone
import math
from .model import ZONES, PARAMETERS

def stamp(now=None):
    return (now or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00","Z")

def build_packet(instance_id, sequence, config_revision, plant, zones, now=None):
    packet={"schema":"motor-pump-twin.telemetry","schema_version":1,
      "instance_id":instance_id,"device_id":"virtual-sensors-01","asset_id":"motor-pump-5hp",
      "sequence":sequence,"acquired_at":stamp(now),"source":"simulated",
      "quality":"saturated" if any(z["quality"]=="saturated" for z in zones.values()) else "synthetic",
      "config_revision":config_revision,"simulation_time_s":round(plant.elapsed_s,3),
      "time_scale":plant.settings.time_scale,
      "temperature":{"value":zones["de"]["temperature_c"],"unit":"degC","location":"de","method":"synthetic_contact_probe_12bit"},
      "vibration":{"value":zones["de"]["vibration_rms_m_s2"],"unit":"m/s2","location":"de",
                   "method":"synthetic_vector_acceleration_rms_dc_removed","sample_rate_hz":1000,"window_s":1,"samples_per_axis":1000},
      "zones":zones,"context":{k:round(v,5) for k,v in plant.context.items()}}
    validate(packet)
    return packet

def validate(p):
    if not isinstance(p,dict) or p.get("schema")!="motor-pump-twin.telemetry" or type(p.get("schema_version")) is not int or p["schema_version"]!=1:
        raise ValueError("Esquema de telemetría desconocido.")
    if type(p.get("sequence")) is not int or p["sequence"]<=0 or p.get("source")!="simulated":
        raise ValueError("Secuencia u origen inválido.")
    dt=datetime.fromisoformat(p["acquired_at"].replace("Z","+00:00"))
    if dt.tzinfo is None:
        raise ValueError("La adquisición requiere zona horaria.")
    if set(p.get("zones",{}))!=set(ZONES):
        raise ValueError("Faltan zonas de medición.")
    def finite(value):
        return type(value) in (int,float) and math.isfinite(value)
    for z in p["zones"].values():
        if not finite(z["temperature_c"]) or not -55<=z["temperature_c"]<=125 or not finite(z["vibration_rms_m_s2"]) or z["vibration_rms_m_s2"]<0:
            raise ValueError("Canal inválido o no finito.")
    if p["temperature"]["unit"]!="degC" or p["vibration"]["unit"]!="m/s2":
        raise ValueError("Unidades inválidas.")
    if p["temperature"]["value"]!=p["zones"]["de"]["temperature_c"] or p["vibration"]["value"]!=p["zones"]["de"]["vibration_rms_m_s2"]:
        raise ValueError("Los canales principales deben corresponder al rodamiento DE.")
    if p["quality"] not in {"synthetic","saturated"}:
        raise ValueError("Calidad inválida.")
    return p
