"""HTTP push genérico y opcional: solo bucle local, sin proxy ni redirecciones."""
from urllib.parse import urlsplit
from http.client import HTTPConnection
import json
import time
from .contract import stamp

def validate_target(url):
    if not isinstance(url,str) or len(url)>500:
        raise ValueError("URL inválida.")
    parsed=urlsplit(url)
    try: port=parsed.port or 80
    except ValueError: raise ValueError("Puerto inválido.") from None
    if parsed.scheme!="http" or parsed.hostname not in {"127.0.0.1","localhost"} or parsed.username or parsed.password or parsed.fragment or not 1<=port<=65535 or any(c in url for c in "\r\n\x00"):
        raise ValueError("Use http://127.0.0.1:PUERTO/ruta o localhost; sin credenciales ni redirecciones.")
    return url

class Sender:
    def __init__(self, engine):
        self.engine=engine
        self.last_attempt=None
    def tick(self):
        e=self.engine
        with e.lock:
            s=e.status()
            integration=s["integration"]
            p=s["current"]
            if not integration["enabled"] or not p:
                return
            key=(integration["generation"],p["sequence"])
            if key==self.last_attempt:
                return
            self.last_attempt=key
            target=urlsplit(integration["url"])
            generation=integration["generation"]
        connection=HTTPConnection("127.0.0.1",target.port or 80,timeout=1.5)
        try:
            body=json.dumps(p,ensure_ascii=False,allow_nan=False).encode("utf-8")
            connection.request("POST",(target.path or "/")+("?"+target.query if target.query else ""),body,{"Content-Type":"application/json","X-Simulator-Schema":"motor-pump-twin.telemetry/1"})
            response=connection.getresponse()
            response.read(4096)
            ok=200<=response.status<300
            detail=f"HTTP {response.status}. "+("Paquete aceptado." if ok else "Receptor rechazó el paquete; no se reintentará este paquete.")
        except (OSError,ValueError) as exc:
            ok=False
            detail="Receptor no disponible. La simulación continúa; se intentará con datos nuevos."
        finally:
            connection.close()
        with e.lock:
            # Una desconexión durante una petición impide atribuir su respuesta a la sesión nueva.
            if e.integration["generation"]!=generation or not e.integration["enabled"]:
                return
            e.integration["state"]="connected" if ok else "unavailable"
            e.integration["detail"]=detail
            e.integration["sent" if ok else "failed"]+=1
            if ok:e.integration["last_sent_at"]=stamp()
