"""Inicio Windows comprobado: espera HTTP, reutiliza la instancia y permite cerrarla."""
import argparse
from http.client import HTTPConnection, HTTPException
import json
from pathlib import Path
import socket
import subprocess
import sys
import time
import webbrowser

APPLICATION_ID = "motor-pump-twin"


def running(port):
    connection = HTTPConnection("127.0.0.1", port, timeout=.6)
    try:
        connection.request("GET", "/api/meta")
        response = connection.getresponse()
        raw = response.read(32768)
        metadata = json.loads(raw)
        return response.status == 200 and isinstance(metadata, dict) and metadata.get("application_id") == APPLICATION_ID
    except (OSError, ValueError, HTTPException):
        return False
    finally:
        connection.close()


def stop(port):
    if not running(port):
        print(f"No hay un Motor / Lab disponible en 127.0.0.1:{port}. No se cerró ningún otro programa.")
        return 1
    connection = HTTPConnection("127.0.0.1", port, timeout=5)
    try:
        body = json.dumps({"confirm": True})
        connection.request("POST", "/api/shutdown", body, {"Content-Type": "application/json"})
        response = connection.getresponse()
        response.read()
        if response.status != 200:
            print("El simulador no pudo confirmar el cierre.")
            return 1
        print("Simulador cerrado; estado e historial guardados.")
        return 0
    except OSError as error:
        print(f"No se pudo cerrar: {error}")
        return 1
    finally:
        connection.close()


def open_page(port):
    url = f"http://127.0.0.1:{port}"
    try:
        opened = webbrowser.open(url)
    except (OSError, webbrowser.Error):
        opened = False
    print(("Página abierta: " if opened else "Abre esta dirección en tu navegador: ") + url, flush=True)


def main():
    parser = argparse.ArgumentParser(description="Abrir o cerrar Motor / Lab local.")
    parser.add_argument("--port", type=int, default=8766)
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--open-browser", action="store_true")
    parser.add_argument("--no-browser", action="store_false", dest="open_browser")
    parser.add_argument("--stop", action="store_true")
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("Use un puerto entre 1024 y 65535.")
    if args.stop:
        return stop(args.port)
    if running(args.port):
        print("Motor / Lab ya está funcionando. Se reutiliza esa instancia.", flush=True)
        if args.open_browser:
            open_page(args.port)
        return 0
    probe = socket.socket()
    try:
        probe.bind(("127.0.0.1", args.port))
    except OSError:
        print(f"El puerto {args.port} está ocupado o no está disponible. Usa --port 8767 o cierra la instancia anterior.", flush=True)
        return 1
    finally:
        probe.close()
    command = [sys.executable, "-m", "twin.server", "--port", str(args.port), "--no-browser"]
    if args.data_dir:
        command += ["--data-dir", str(args.data_dir.resolve())]
    child = subprocess.Popen(command, cwd=Path(__file__).resolve().parent.parent)
    try:
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            if child.poll() is not None:
                print("El servicio no pudo iniciar. Revisa el mensaje anterior.", flush=True)
                return child.returncode or 1
            if running(args.port):
                if args.open_browser:
                    open_page(args.port)
                return child.wait()
            time.sleep(.15)
        print("El servicio no respondió a tiempo; revisa operacion.log y vuelve a iniciar.", flush=True)
        child.terminate()
        child.wait(timeout=5)
        return 1
    except KeyboardInterrupt:
        # Ctrl+C llega también al hijo cuando comparte la consola de Windows.
        try:
            return child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            child.terminate()
            child.wait(timeout=5)
            return 0


if __name__ == "__main__":
    sys.exit(main())
