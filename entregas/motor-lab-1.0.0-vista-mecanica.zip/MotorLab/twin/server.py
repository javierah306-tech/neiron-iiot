"""Aplicación local autocontenida, REST + SSE + CSV; sin dependencia de navegador externo."""
import argparse
import csv
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
from threading import Event, Thread, BoundedSemaphore
import time
from urllib.parse import urlsplit, parse_qs
import webbrowser
from .engine import Engine
from .storage import Storage
from .transport import Sender
from .contract import stamp

STATIC=Path(__file__).with_name("static")

class Server(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self, address, engine):
        super().__init__(address, Handler)
        self.engine=engine
        self.stop_event=Event()
        self.stream_slots=BoundedSemaphore(4)

class Handler(BaseHTTPRequestHandler):
    protocol_version="HTTP/1.1"
    def handle(self):
        try:
            super().handle()
        except (ConnectionResetError,ConnectionAbortedError,BrokenPipeError):
            self.close_connection=True
    def log_message(self, format, *args):
        logging.info("%s %s", self.client_address[0],format % args)
    def guard(self):
        port=self.server.server_address[1]
        host=self.headers.get("Host","")
        if self.client_address[0]!="127.0.0.1" or host not in {f"127.0.0.1:{port}",f"localhost:{port}"}:
            self.respond(403,{"error":"Acceso reservado al bucle local y al puerto del simulador."})
            return False
        navigation=(self.command=="GET" and urlsplit(self.path).path=="/"
                    and self.headers.get("Sec-Fetch-Mode")=="navigate"
                    and self.headers.get("Sec-Fetch-Dest")=="document")
        origin=self.headers.get("Origin")
        if origin and not navigation and origin not in {f"http://127.0.0.1:{port}",f"http://localhost:{port}"}:
            self.respond(403,{"error":"Origen no autorizado. Use la API desde un cliente local, sin CORS."})
            return False
        if self.headers.get("Sec-Fetch-Site")=="cross-site" and not navigation:
            self.respond(403,{"error":"Solicitud desde otro sitio bloqueada."})
            return False
        return True
    def common_headers(self, status, content_type, length=None):
        self.send_response(status)
        self.send_header("Content-Type",content_type)
        if length is not None:self.send_header("Content-Length",str(length))
        self.send_header("Cache-Control","no-store")
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Referrer-Policy","no-referrer")
        self.send_header("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; font-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'")
        self.end_headers()
    def respond(self, status, payload):
        body=json.dumps(payload,ensure_ascii=False,allow_nan=False).encode("utf-8")
        self.common_headers(status,"application/json; charset=utf-8",len(body))
        self.wfile.write(body)
    def date_range(self, query):
        vals=[]
        for key,fallback in (("from",""),("to","~")):
            raw=query.get(key,[fallback])[0]
            if raw not in {"","~"}:
                try:
                    dt=datetime.fromisoformat(raw.replace("Z","+00:00"))
                    if dt.tzinfo is None:raise ValueError()
                    raw=stamp(dt)
                except (ValueError,TypeError):raise ValueError("Las fechas del intervalo necesitan ISO 8601 con zona horaria.") from None
            vals.append(raw)
        if vals[0]>vals[1]:raise ValueError("La fecha inicial debe preceder a la final.")
        return vals
    def do_GET(self):
        try:
            if not self.guard():return
            parsed=urlsplit(self.path)
            path=parsed.path
            query=parse_qs(parsed.query)
            engine=self.server.engine
            if path=="/api/status":self.respond(200,engine.status())
            elif path=="/api/meta":self.respond(200,engine.metadata())
            elif path=="/api/latest":
                s=engine.status()
                self.respond(200 if s["current"] else 503,s["current"] or {"error":"Sin paquete actual.","state":s["state"]})
            elif path=="/api/history":
                start,end=self.date_range(query)
                limit=int(query.get("limit",["600"])[0])
                if not 1<=limit<=1000:raise ValueError("El límite del historial debe estar entre 1 y 1000.")
                self.respond(200,{"rows":engine.store.history(start,end,limit)})
            elif path=="/api/stream":self.stream()
            elif path=="/api/export.csv":self.export(query)
            elif path in {"/","/app.js","/app.css","/mechanics.js","/mechanics.css"}:
                filename="index.html" if path=="/" else path[1:]
                body=(STATIC/filename).read_bytes()
                mime="text/html" if filename=="index.html" else "text/css" if filename.endswith(".css") else "application/javascript"
                self.common_headers(200,mime+"; charset=utf-8",len(body));self.wfile.write(body)
            elif path=="/favicon.ico":self.common_headers(204,"image/x-icon",0)
            else:self.respond(404,{"error":"Ruta inexistente. Consulte API.md para conectar un cliente local."})
        except (BrokenPipeError,ConnectionResetError):pass
        except (ValueError,TypeError,KeyError) as exc:self.respond(400,{"error":str(exc)})
        except Exception:
            logging.exception("GET falló")
            self.respond(500,{"error":"No fue posible atender la solicitud. Consulte el registro local."})
    def do_POST(self):
        try:
            if not self.guard():return
            length=int(self.headers.get("Content-Length","0"))
            if not 0<length<=32768:raise ValueError("El cuerpo debe contener JSON de hasta 32 KB.")
            if self.headers.get("Content-Type","").split(";")[0]!="application/json":
                self.respond(415,{"error":"Use Content-Type: application/json."});return
            raw=json.loads(self.rfile.read(length).decode("utf-8"),parse_constant=lambda v:(_ for _ in ()).throw(ValueError("JSON no admite NaN ni infinito.")))
            if not isinstance(raw,dict):raise ValueError("Se esperaba un objeto JSON.")
            engine=self.server.engine
            path=urlsplit(self.path).path
            if path=="/api/parameters":engine.configure(raw)
            elif path=="/api/control" and set(raw)=={"action"}:engine.command(raw["action"])
            elif path=="/api/integration" and set(raw)=={"url","enabled"}:
                if raw["enabled"] and urlsplit(raw["url"]).port==self.server.server_address[1]:
                    raise ValueError("El receptor debe ser otra aplicación; no use el puerto del simulador.")
                engine.integration_configure(raw["url"],raw["enabled"])
            elif path=="/api/shutdown" and raw=={"confirm":True} and type(raw["confirm"]) is bool:
                self.respond(200,{"closing":True})
                Thread(target=self.server.shutdown,daemon=True).start()
                return
            else:self.respond(404,{"error":"Ruta o campos desconocidos."});return
            self.respond(200,engine.status())
        except (BrokenPipeError,ConnectionResetError):pass
        except (ValueError,TypeError,KeyError) as exc:self.respond(400,{"error":str(exc)})
        except Exception:
            logging.exception("POST falló")
            self.respond(500,{"error":"No se pudo guardar el cambio. Consulte el registro local."})
    def stream(self):
        if not self.server.stream_slots.acquire(blocking=False):
            self.respond(429,{"error":"Hay cuatro flujos abiertos; cierre uno y vuelva a conectar."});return
        try:
            self.common_headers(200,"text/event-stream; charset=utf-8")
            last=None
            last_state=None
            while not self.server.stop_event.is_set():
                s=self.server.engine.status()
                if s["state"]!=last_state:
                    data=json.dumps({"state":s["state"],"current_available":s["current"] is not None})
                    self.wfile.write(f"event: status\ndata: {data}\n\n".encode())
                    last_state=s["state"]
                p=s["current"]
                if p and p["sequence"]!=last:
                    self.wfile.write((f"id: {p['sequence']}\nevent: telemetry\ndata: "+json.dumps(p,ensure_ascii=False)+"\n\n").encode("utf-8"))
                    last=p["sequence"]
                else:self.wfile.write(b": heartbeat\n\n")
                self.wfile.flush()
                self.server.stop_event.wait(1)
        except (OSError,ConnectionError):pass
        finally:
            self.close_connection=True
            self.server.stream_slots.release()
    def export(self, query):
        start,end=self.date_range(query)
        self.send_response(200)
        self.send_header("Content-Type","text/csv; charset=utf-8")
        self.send_header("Content-Disposition",'attachment; filename="motor-bomba-simulado.csv"')
        self.send_header("Cache-Control","no-store")
        self.send_header("Connection","close")
        self.end_headers()
        self.close_connection=True
        self.wfile.write(b"\xef\xbb\xbf")
        buf=io.StringIO(newline="")
        writer=csv.writer(buf,delimiter=";")
        columns=["schema_version","instance_id","sequence","acquired_at_utc","received_at_utc","simulation_time_s","time_scale","source","quality","config_revision","device_id","asset_id","temperature_unit","vibration_unit","vibration_method","sample_rate_hz","window_s"]
        zones=("nde","casing","de","pump")
        for z in zones:columns.extend([f"{z}_temperature_degC",f"{z}_vibration_rms_m_s2",f"{z}_quality"])
        writer.writerow(columns)
        self.wfile.write(buf.getvalue().encode("utf-8"));buf.seek(0);buf.truncate(0)
        for p in self.server.engine.store.export(start,end):
            row=[p["schema_version"],p["instance_id"],p["sequence"],p["acquired_at"],p["received_at"],p["simulation_time_s"],p["time_scale"],p["source"],p["quality"],p["config_revision"],p["device_id"],p["asset_id"],"degC","m/s2",p["vibration"]["method"],1000,1]
            for z in zones:row.extend([p["zones"][z]["temperature_c"],p["zones"][z]["vibration_rms_m_s2"],p["zones"][z]["quality"]])
            writer.writerow(row);self.wfile.write(buf.getvalue().encode("utf-8"));buf.seek(0);buf.truncate(0)

def main():
    parser=argparse.ArgumentParser(description="Gemelo virtual autónomo motor–bomba, siempre simulado.")
    parser.add_argument("--port",type=int,default=8766)
    parser.add_argument("--data-dir",type=Path)
    parser.add_argument("--open-browser",action="store_true")
    parser.add_argument("--no-browser",action="store_false",dest="open_browser")
    args=parser.parse_args()
    if not 1024<=args.port<=65535:parser.error("Use un puerto entre 1024 y 65535.")
    directory=args.data_dir or Path(os.environ.get("LOCALAPPDATA",str(Path.home()/".local"/"share")))/"MotorPumpTwin"
    store=Storage(directory)
    logging.basicConfig(level=logging.INFO,handlers=[RotatingFileHandler(directory/"operacion.log",maxBytes=2_000_000,backupCount=2,encoding="utf-8")],format="%(asctime)s %(levelname)s %(message)s")
    try:
        engine=Engine(store)
        server=Server(("127.0.0.1",args.port),engine)
    except (OSError,ValueError,KeyError) as exc:
        store.close()
        parser.exit(1,f"No se pudo iniciar: {exc}\nSi el puerto está ocupado, cierre esa instancia o use --port 8767.\n")
    sender=Sender(engine)
    def physics():
        previous=time.monotonic()
        while not server.stop_event.wait(1):
            now=time.monotonic();dt=min(5,now-previous);previous=now
            try:engine.tick(dt)
            except Exception:
                logging.exception("Fallo de adquisición simulada")
                with engine.lock:engine.error="La adquisición simulada se detuvo por un error; consulte operacion.log."
    def transmit():
        while not server.stop_event.wait(.5):
            try:sender.tick()
            except Exception:logging.exception("Fallo de salida HTTP")
    workers=[Thread(target=physics,daemon=True),Thread(target=transmit,daemon=True)]
    for worker in workers:worker.start()
    url=f"http://127.0.0.1:{args.port}"
    print(f"Motor–bomba · simulador independiente 1.0.0\n{url}\nDatos SIMULADOS. Salida HTTP desactivada.\nDatos locales: {directory}\nCtrl+C para cerrar.",flush=True)
    if args.open_browser:webbrowser.open(url)
    try:server.serve_forever(poll_interval=.25)
    except KeyboardInterrupt:print("\nCerrando y guardando estado...",flush=True)
    finally:
        server.stop_event.set()
        for worker in workers:worker.join(timeout=3)
        server.server_close()
        with engine.lock:engine.persist()
        store.close()

if __name__=="__main__":main()

