"""Persistencia autónoma, sin rutas ni importaciones de neiron."""
from pathlib import Path
import sqlite3
import json
from threading import RLock
from .contract import stamp, validate

class Storage:
    def __init__(self, directory):
        self.directory=Path(directory)
        self.directory.mkdir(parents=True,exist_ok=True)
        self.path=self.directory/"twin.sqlite3"
        self.lock=RLock()
        self.db=sqlite3.connect(self.path,check_same_thread=False)
        self.db.row_factory=sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS state (id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS packets (sequence INTEGER PRIMARY KEY, acquired_at TEXT NOT NULL, received_at TEXT NOT NULL, source TEXT NOT NULL, data TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS packet_date ON packets(acquired_at);
        CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, recorded_at TEXT NOT NULL, event TEXT NOT NULL, detail TEXT NOT NULL);
        PRAGMA user_version=1;
        """)
        self.db.commit()
    def load(self):
        row=self.db.execute("SELECT value FROM state WHERE id=1").fetchone()
        return json.loads(row[0]) if row else None
    def last_sequence(self):
        return self.db.execute("SELECT COALESCE(MAX(sequence),0) FROM packets").fetchone()[0]
    def save(self, state, packet=None):
        with self.lock, self.db:
            if packet:
                validate(packet)
                last=self.last_sequence()
                if packet["sequence"]<=last:
                    raise ValueError("Paquete duplicado o fuera de orden; no guardado.")
                self.db.execute("INSERT INTO packets VALUES (?,?,?,?,?)",(packet["sequence"],packet["acquired_at"],stamp(),packet["source"],json.dumps(packet,ensure_ascii=False,allow_nan=False)))
            self.db.execute("INSERT INTO state VALUES(1,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value",(json.dumps(state,ensure_ascii=False,allow_nan=False),))
    def event(self, name, detail):
        with self.lock,self.db:
            self.db.execute("INSERT INTO events(recorded_at,event,detail) VALUES(?,?,?)",(stamp(),name,json.dumps(detail,ensure_ascii=False)))
    def history(self, start="", end="~", limit=600):
        with self.lock:
            rows=self.db.execute("SELECT data,received_at FROM packets WHERE acquired_at>=? AND acquired_at<=? ORDER BY sequence DESC LIMIT ?",(start,end,limit)).fetchall()
        return [{**json.loads(r[0]),"received_at":r[1]} for r in reversed(rows)]
    def export(self, start="", end="~"):
        conn=sqlite3.connect(self.path)
        try:
            for row in conn.execute("SELECT data,received_at FROM packets WHERE acquired_at>=? AND acquired_at<=? ORDER BY sequence",(start,end)):
                yield {**json.loads(row[0]),"received_at":row[1]}
        finally:
            conn.close()
    def count(self):
        with self.lock:
            return self.db.execute("SELECT COUNT(*) FROM packets").fetchone()[0]
    def close(self):
        with self.lock:
            self.db.close()
