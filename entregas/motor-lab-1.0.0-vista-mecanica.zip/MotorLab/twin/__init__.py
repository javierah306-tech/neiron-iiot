"""Simulador autónomo motor–bomba. Ninguna dependencia de neiron."""
__version__ = "1.0.0"
