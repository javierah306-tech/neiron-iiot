"""Modelo reducido e ilustrativo; constantes térmicas y defectos no calibrados."""
from dataclasses import dataclass, asdict
import math
import random

ZONES = {"nde": "Rodamiento posterior · NDE", "casing": "Carcasa del motor",
         "de": "Rodamiento del acoplamiento · DE", "pump": "Bomba de agua"}
PARAMETERS = {"rated_power_kw": 3.7, "voltage_v": 230, "line_hz": 50, "poles": 2,
              "rated_rpm": 2910, "efficiency": 0.85, "sample_rate_hz": 1000,
              "window_s": 1, "impeller_blades": 6, "water_density_kg_m3": 1000}
# key: minimum, maximum, unit, title, help (indicadores sin magnitud física: porcentajes de escenario)
FIELDS = {
 "ambient_c": (0,45,"°C","Temperatura ambiente","Afecta la disipación de todas las zonas."),
 "water_c": (5,40,"°C","Temperatura del agua","Agua limpia, sin sólidos; afecta el enfriamiento de la bomba."),
 "valve_pct": (25,120,"%","Apertura relativa de válvula","100 % es el punto nominal supuesto; cambia caudal y carga."),
 "cooling_pct": (5,100,"%","Ventilación disponible","Menos refrigeración eleva gradualmente la temperatura del motor."),
 "lubrication_pct": (0,100,"%","Lubricación efectiva","Índice ilustrativo: 100 % adecuado; reducirlo añade fricción y ruido."),
 "contamination_pct": (0,100,"%","Contaminación del lubricante","Índice de escenario en rodamientos; el agua bombeada sigue limpia."),
 "misalignment_mm": (0,1.5,"mm","Desalineación paralela","Desplazamiento supuesto del acoplamiento, sin tolerancia certificada."),
 "imbalance_gmm": (0,400,"g·mm","Desequilibrio del rotor","Masa excéntrica × radio; refuerza la componente a una vuelta."),
 "looseness_pct": (0,100,"%","Holgura de la fijación","Índice ilustrativo de base suelta; añade armónicos a motor y bomba."),
 "bearing_defect_pct": (0,100,"%","Defecto de rodamiento","Intensidad de impulsos sintéticos; no es porcentaje de vida consumida."),
 "suction_margin_m": (0.2,5,"m","NPSH disponible supuesto","Bajo 2,5 m aparece cavitación en esta bomba ilustrativa."),
 "time_scale": (1,60,"×","Velocidad del tiempo físico","1×, 10× o 60×; paquetes y fechas siguen el reloj real.")}

@dataclass
class Settings:
    ambient_c: float = 22
    water_c: float = 20
    valve_pct: float = 100
    cooling_pct: float = 100
    lubrication_pct: float = 100
    contamination_pct: float = 0
    misalignment_mm: float = 0
    imbalance_gmm: float = 0
    looseness_pct: float = 0
    bearing_defect_pct: float = 0
    suction_margin_m: float = 3.5
    time_scale: float = 1

    def updated(self, raw):
        if not isinstance(raw, dict) or not raw or set(raw) - FIELDS.keys():
            raise ValueError("Envíe uno o más parámetros conocidos del modelo.")
        vals = asdict(self)
        for key, val in raw.items():
            low, high, _, label, _ = FIELDS[key]
            if isinstance(val, bool) or not isinstance(val, (int,float)) or not math.isfinite(val) or not low <= val <= high:
                raise ValueError(f"{label}: use un número entre {low} y {high}.")
            if key == "time_scale" and val not in (1,10,60):
                raise ValueError("Seleccione tiempo físico 1×, 10× o 60×.")
            vals[key] = float(val)
        return Settings(**vals)

PRESETS = {
 "normal": {"label":"Agua · operación normal", "values":asdict(Settings())},
 "lubrication": {"label":"Lubricación insuficiente", "values":{"lubrication_pct":10}},
 "alignment": {"label":"Desalineación", "values":{"misalignment_mm":1.1}},
 "imbalance": {"label":"Desequilibrio", "values":{"imbalance_gmm":320}},
 "cooling": {"label":"Refrigeración deficiente", "values":{"cooling_pct":10}},
 "bearing": {"label":"Defecto de rodamiento", "values":{"bearing_defect_pct":85}},
 "cavitation": {"label":"Cavitación", "values":{"suction_margin_m":0.6}}}

class Plant:
    def __init__(self, seed=512):
        self.settings = Settings()
        self.seed = seed
        self.motor_on = True
        self.elapsed_s = 0.0
        self.rpm = 0.0
        self.temperatures = {z:22.0 if z != "pump" else 20.0 for z in ZONES}
        self.probes = self.temperatures.copy()
        self.phase = 0.0
        self.zones = {}
        self.waveforms = {}
        self.context = {}

    def hydraulics(self, rpm):
        s = self.settings
        r = max(0, rpm / 2910)
        valve = s.valve_pct / 100
        # H_p = 65*r² - 20*(Q/18)²; H_s = (45/v²)*(Q/18)² [m]
        qratio = r * math.sqrt(65 / (20 + 45/valve**2))
        cav = max(0, min(1, (2.5 - s.suction_margin_m)/2.5))
        flow = 18 * qratio * (1 - .25*cav)
        head = 45/valve**2 * qratio**2 * (1 - .20*cav)
        eta = max(.38, .64 * math.exp(-.7*(qratio/max(r,.001)-1)**2))
        hydraulic = 1000 * 9.80665 * flow/3600 * head
        shaft = hydraulic/eta + 120*r**3
        return {"flow_m3h":flow, "head_m":head, "pressure_bar":head*.0980665,
                "hydraulic_power_w":hydraulic, "pump_shaft_w":shaft,
                "pump_efficiency":eta, "cavitation_index":cav, "pump_load":shaft/3700}

    def step(self, dt):
        if not math.isfinite(dt) or not 0 <= dt <= 5:
            raise ValueError("El paso real debe estar entre 0 y 5 segundos.")
        remaining = dt * self.settings.time_scale
        s = self.settings
        while remaining > 1e-8:
            h = min(remaining,1)
            hydraulics = self.hydraulics(self.rpm)
            lube = (1-s.lubrication_pct/100)
            contamination = s.contamination_pct/100
            alignment = s.misalignment_mm/1.5
            defect = s.bearing_defect_pct/100
            friction = (140*lube**2 + 75*contamination + 85*alignment**2 + 65*defect)
            target = max(0,3000 - 30 - 60*(hydraulics["pump_load"]+friction/3700)) if self.motor_on else 0
            self.rpm += (target-self.rpm)*(1-math.exp(-h/(1.1 if self.motor_on else 1.8)))
            ratio = min(1.15, self.rpm/2910)
            p = self.hydraulics(self.rpm)
            bearing_heat = friction * ratio
            # Potencias siempre no negativas. El rotor en desaceleración puede calentar por fricción.
            losses = (180 + (3700/.85-3700-180)*p["pump_load"]**2) if self.motor_on else 0
            g = 18.18*(.35+.65*ratio)*s.cooling_pct/100 if self.motor_on else 5.5
            t = self.temperatures
            old = t.copy()
            # 32 W nominales del total de pérdidas se depositan en los dos rodamientos.
            heat_casing = max(0, losses - (32*ratio if self.motor_on else 0))
            t["casing"] += (heat_casing - g*(old["casing"]-s.ambient_c)
                              + 2*(old["de"]-old["casing"]) + 2*(old["nde"]-old["casing"])) * h/16000
            for key, weight, cap in (("de",.65,2400),("nde",.35,1800)):
                heat = (16*ratio if self.motor_on else 0) + weight*bearing_heat
                t[key] += (heat + 2*(old["casing"]-old[key])
                            - 2.5*(old[key]-s.ambient_c))*h/cap
            t["pump"] += (p["pump_shaft_w"]-p["hydraulic_power_w"]
                           - (35+18*p["flow_m3h"])*(old["pump"]-s.water_c))*h/6000
            for key in ZONES:
                self.probes[key] += (t[key]-self.probes[key])*(1-math.exp(-h/8))
            self.elapsed_s += h
            remaining -= h
            self.context = {**p,"rpm":self.rpm,"bearing_friction_w":bearing_heat,
                            "motor_losses_w":losses,"electrical_power_w":(p["pump_shaft_w"]+bearing_heat+losses) if self.motor_on else 0,
                            "motor_load_pct":100*(p["pump_shaft_w"]+bearing_heat)/3700,
                            "synchronous_rpm":3000}

    def acquire(self, sequence):
        s = self.settings
        r = min(1.15,self.rpm/2910)
        f = self.rpm/60
        p = self.hydraulics(self.rpm)
        rng = random.Random(self.seed+sequence)
        a1 = (.55+.2*p["pump_load"]+s.imbalance_gmm*.010)*r**2
        a2 = (.14+s.misalignment_mm*4.1)*r**2
        loose = s.looseness_pct/100 * 1.6*r**2
        noise = (.03+1.4*(1-s.lubrication_pct/100)**2 + .8*s.contamination_pct/100)*r+.01
        defect = s.bearing_defect_pct/100 * 8*r
        cav = p["cavitation_index"]*3.4*r
        weights = {"nde":(.78,.4,.7,.35), "casing":(.7,.45,.35,.3),
                   "de":(1,1,1,1), "pump":(.55,.6,.15,1.7)}
        zones, waves = {}, {}
        for zone,(w1,w2,wn,wc) in weights.items():
            axes=[[],[],[]]
            for i in range(1000):
                angle=self.phase+2*math.pi*f*i/1000
                first=a1*w1*math.sin(angle)
                second=a2*w2*math.sin(2*angle+.2)
                blade=.2*r**2*math.sin(6*angle+.7)
                rough=rng.gauss(0,noise*wn+cav*wc)
                # Impulsos periódicos SUPUESTOS ~4,7× giro; sin geometría ni diagnóstico BPFO/BPFI.
                impact=defect*wn*max(0,math.sin(4.7*angle))**20*rng.uniform(.85,1.15)
                harmonic=loose*math.sin(3*angle+.4)
                electrical=.2*r*math.sin(2*math.pi*100*i/1000) if self.motor_on else 0
                axes[0].append(first+second+.5*blade+harmonic+.45*rough+impact)
                axes[1].append(.8*a1*w1*math.cos(angle)+.35*second+rough+electrical+.6*impact)
                axes[2].append(.35*first+.7*second+.45*blade+.5*rough+.4*harmonic+.35*impact)
            means = [sum(axis)/1000 for axis in axes]
            centered = [[v-means[j] for v in axis] for j,axis in enumerate(axes)]
            rms_axes = [math.sqrt(sum(v*v for v in axis)/1000) for axis in centered]
            rms=math.sqrt(sum(v*v for v in rms_axes))
            measured = round((self.probes[zone]+rng.gauss(0,.012))*16)/16
            saturated=measured>125 or measured< -55
            measured=max(-55,min(125,measured))
            zones[zone] = {"name":ZONES[zone],"temperature_c":measured,
                "vibration_rms_m_s2":round(rms,6),"rms_axes_m_s2":[round(v,6) for v in rms_axes],
                "quality":"saturated" if saturated else "synthetic"}
            waves[zone] = [{"t_ms":i,"x":round(centered[0][i],4),"y":round(centered[1][i],4),"z":round(centered[2][i],4)} for i in range(120)]
        self.phase=(self.phase+2*math.pi*f)%(2*math.pi)
        self.zones=zones
        self.waveforms=waves
        return zones

    def saved(self):
        return {"settings":asdict(self.settings),"motor_on":self.motor_on,"elapsed_s":self.elapsed_s,
                "rpm":self.rpm,"temperatures":self.temperatures,"probes":self.probes,"phase":self.phase}

    def restore(self, raw):
        self.settings=self.settings.updated(raw["settings"])
        self.motor_on=bool(raw["motor_on"])
        for name in ("elapsed_s","rpm","phase"):
            val=raw[name]
            if isinstance(val,bool) or not isinstance(val,(int,float)) or not math.isfinite(val) or val<0:
                raise ValueError("Estado físico inválido.")
            setattr(self,name,val)
        for name in ("temperatures","probes"):
            vals=raw[name]
            if set(vals)!=set(ZONES) or any(not isinstance(v,(int,float)) or not math.isfinite(v) or not -55<=v<=500 for v in vals.values()):
                raise ValueError("Temperaturas guardadas inválidas.")
            setattr(self,name,vals)
