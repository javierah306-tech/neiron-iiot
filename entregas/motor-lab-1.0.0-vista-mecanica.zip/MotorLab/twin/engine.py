"""Reloj y comandos. La integración no gobierna ni bloquea el modelo."""
from threading import RLock
from collections import deque
from dataclasses import asdict
import time
import uuid
from .model import Plant, FIELDS, PRESETS, ZONES, PARAMETERS
from .contract import build_packet, stamp
from . import __version__

class Engine:
    def __init__(self, store, monotonic=time.monotonic):
        self.lock=RLock()
        self.store=store
        self.clock=monotonic
        self.plant=Plant()
        self.sequence=store.last_sequence()
        self.instance_id=str(uuid.uuid4())
        self.config_revision=1
        self.running=True
        self.signal=True
        self.latest=None
        self.latest_at=None
        self.error=None
        self.trend=deque(maxlen=240)
        self.integration={"enabled":False,"url":"","generation":0,"state":"disabled","sent":0,"failed":0,"last_sent_at":None,"detail":"Salida desactivada. Elige un receptor cuando lo necesites."}
        saved=store.load()
        if saved:
            self.plant.restore(saved["plant"])
            self.sequence=max(self.sequence,saved["sequence"])
            self.instance_id=saved["instance_id"]
            self.config_revision=saved["config_revision"]
            self.running=saved.get("running",True)
            self.signal=saved.get("signal",True)
            self.integration["url"]=saved.get("target_url","")
        self.store.event("session_started",{"push_enabled":False,"version":__version__})
        self.persist()

    def saved(self):
        return {"plant":self.plant.saved(),"sequence":self.sequence,"instance_id":self.instance_id,
                "config_revision":self.config_revision,"running":self.running,"signal":self.signal,
                "target_url":self.integration["url"]}
    def persist(self, packet=None):
        self.store.save(self.saved(),packet)
    def tick(self, dt=1):
        with self.lock:
            if not self.running:
                return
            self.plant.step(dt)
            # También en pérdida de telemetría la planta continúa evolucionando.
            zones=self.plant.acquire(self.sequence+1)
            if self.signal:
                next_sequence=self.sequence+1
                packet=build_packet(self.instance_id,next_sequence,self.config_revision,self.plant,zones)
                self.sequence=next_sequence
                self.persist(packet)
                self.latest=packet
                self.latest_at=self.clock()
                self.trend.append({"acquired_at":packet["acquired_at"],"simulation_time_s":packet["simulation_time_s"],"zones":packet["zones"]})
            else:
                self.persist()
            self.error=None
    def configure(self, raw):
        with self.lock:
            self.plant.settings=self.plant.settings.updated(raw)
            self.config_revision+=1
            self.store.event("parameters_changed",{"revision":self.config_revision,"changes":raw})
            self.persist()
    def command(self, command):
        with self.lock:
            if command in PRESETS:
                values=PRESETS[command]["values"].copy()
                # Recuperar modifica causas; conserva temperaturas y escala seleccionada.
                if command=="normal":
                    values["time_scale"]=self.plant.settings.time_scale
                self.configure(values)
            elif command=="pause": self.running=False
            elif command=="resume": self.running=True
            elif command=="motor_on": self.plant.motor_on=True
            elif command=="motor_off": self.plant.motor_on=False
            elif command=="signal_loss": self.signal=False
            elif command=="signal_restore": self.signal=True
            else: raise ValueError("Control desconocido.")
            if command in {"pause","signal_loss","resume","signal_restore"}:
                self.latest=None
                self.latest_at=None
            self.store.event("command",{"action":command})
            self.persist()
    def integration_configure(self, url, enabled):
        from .transport import validate_target
        if type(enabled) is not bool:
            raise ValueError("El estado del envío debe ser verdadero o falso.")
        valid=validate_target(url) if url else ""
        if enabled and not valid:
            raise ValueError("Escribe la URL HTTP local del receptor antes de conectar.")
        with self.lock:
            self.integration.update(enabled=enabled,url=valid,generation=self.integration["generation"]+1,
                state="waiting" if enabled else "disabled",detail="Esperando un paquete nuevo." if enabled else "Salida desactivada por el usuario.")
            self.store.event("integration_changed",{"enabled":enabled,"url":valid})
            self.persist()
    def status(self):
        with self.lock:
            fresh=bool(self.running and self.signal and self.latest and self.latest_at is not None and self.clock()-self.latest_at<4 and not self.error)
            state="error" if self.error else "paused" if not self.running else "signal_loss" if not self.signal else "live" if fresh else "waiting"
            p=self.plant
            return {"version":__version__,"state":state,"error":self.error,"running":self.running,
                    "motor_on":p.motor_on,"signal":self.signal,"sequence":self.sequence,
                    "instance_id":self.instance_id,"elapsed_s":p.elapsed_s,"settings":asdict(p.settings),
                    "config_revision":self.config_revision,"current":self.latest if fresh else None,
                    "last_received_at":self.latest["acquired_at"] if self.latest else None,
                    "plant":{"context":p.context,"zones":p.zones},"waveforms":p.waveforms if fresh else {},
                    "trend":list(self.trend),"integration":self.integration.copy(),
                    "stored_packets":self.store.count(),"data_dir":str(self.store.directory),
                    "ai_enabled":False,"hardware_connected":False}
    def metadata(self):
        return {"application_id":"motor-pump-twin","version":__version__,"parameters":{k:{"min":v[0],"max":v[1],"unit":v[2],"label":v[3],"help":v[4]} for k,v in FIELDS.items()},
                "presets":{k:v["label"] for k,v in PRESETS.items()},"zones":ZONES,"reference":PARAMETERS,
                "display_thresholds":{"temperature_c":75,"vibration_rms_m_s2":3},
                "threshold_notice":"Niveles de visualización ilustrativos, sin clasificación normativa ni diagnóstico."}
