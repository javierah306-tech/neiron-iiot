@echo off
setlocal
set "PYTHONUTF8=1"
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    call instalar.bat
    if errorlevel 1 exit /b 1
)
.venv\Scripts\python.exe -c "import sys,sqlite3; assert sys.version_info[:2] == (3,12)" >nul 2>nul
if errorlevel 1 (
    echo No se puede ejecutar el entorno Python. Abra instalar.bat y revise el mensaje.
    pause
    exit /b 1
)
.venv\Scripts\python.exe -m twin.launcher --open-browser %*
if errorlevel 1 (
    echo No se pudo abrir el simulador. Revise el mensaje anterior.
    pause
)
