# Motor / Lab · simulador autónomo 1.0.0

Aplicación Python independiente para explorar **motor monofásico de 5 HP → acoplamiento → bomba centrífuga de agua limpia**. Vista de planta con aspecto de gemelo virtual, calor rojo por zona, movimiento de vibración, sensores sintéticos, gráficos, controles físicos y exportación. **Siempre genera DATOS SIMULADOS.** No requiere neiron, ESP32, Blender, VSCode, GitHub, internet ni IA para funcionar.

Esta carpeta es la única ubicación principal del simulador actual. Puede copiarse a otro proyecto junto con sus fuentes y lanzadores. No contiene importaciones de neiron, sus estilos, su contrato ni su entorno Python. El banco integrado anterior en `06_PORTAFOLIO_GITHUB/neiron-iiot/software` se conserva como antecedente de la versión 0.2; no es el inicio vigente. Se conservaron los diseños Blender, STL, renders y respaldos.

Para llevarlo a otra PC, copia fuentes, ejemplos, documentos y archivos `.bat`; excluye `.venv`, `__pycache__` y `.test-artifacts`. En el destino prepara un entorno nuevo con `instalar.bat` y Python 3.12 disponible. Los entornos virtuales de Windows no se trasladan como parte del programa.

## Abrir en Windows

1. En el Explorador de Windows, abre `CARPETA_DEL_PROYECTO` y haz doble clic en **`ABRIR MOTOR LAB.lnk`**, el acceso directo preparado en este PC. También funciona **`iniciar.bat`** dentro de esta carpeta o **`INICIAR_SIMULADOR_INDEPENDIENTE.bat`** en la raíz. Un enlace a un archivo en el chat puede mostrar su contenido; el archivo de inicio se ejecuta desde Windows.
2. La primera vez `instalar.bat` prepara `.venv`, su propio entorno aislado, con Python 3.12 ya disponible en el PC. También puede usar el runtime local existente en Codex. No instala paquetes globales, no descarga nada ni cambia el sistema. Si no hay Python 3.12, informa del requisito sin instalarlo automáticamente.
3. Abre **http://127.0.0.1:8766**. La planta empieza encendida en condiciones normales. La salida a otros programas está **desactivada** y no se abre neiron.
4. Para cerrar y guardar, usa **`CERRAR MOTOR LAB.lnk`** o **`CERRAR_SIMULADOR_INDEPENDIENTE.bat`** en la raíz. También sirve `cerrar.bat` dentro de esta carpeta. Si se inició con una consola visible, puedes usar **Ctrl+C** y confirmar **S** si Windows pregunta por el lote. Cerrar la pestaña deja el simulador funcionando. Pausar congela el modelo; apagar motor mantiene sensores virtuales, desaceleración y enfriamiento.

El inicio comprueba que la página está lista antes de abrir el navegador. Si este simulador ya está ejecutándose, abre la instancia existente y conserva sus parámetros/datos. Los accesos `.lnk` contienen la ubicación de este PC: al trasladar el programa a otra ubicación, utiliza los `.bat` portables.

Si 8766 está ocupado por el banco anterior, cierra su consola o ejecuta `iniciar.bat --port 8767`. Nunca se detienen otros procesos automáticamente.

Para iniciar únicamente el servidor, sin abrir una pestaña automática: `iniciar.bat --no-browser`.

Desde la terminal de VSCode, con esta carpeta abierta:

```powershell
.\instalar.bat
.\.venv\Scripts\python.exe -m twin.server --open-browser
```

Para cambiar la ubicación de datos:

```powershell
.\.venv\Scripts\python.exe -m twin.server --data-dir "D:\Mis ensayos\MotorPumpTwin" --port 8767
```

Referencia reproducible: CPython **3.12.14**, SQLite **3.53.1**, sin dependencias de terceros (`runtime.txt`, `requirements.txt`). Windows con Edge/Chrome/Firefox reciente para SVG, Canvas, Intl y Fetch. Node/Playwright son herramientas de verificación; el usuario no necesita instalarlas.

## Probar el banco interactivo

La revisión visual del **2 de octubre de 2026** abre el motor **translúcido**. Incluye acabados azules y metálicos más limpios, bobinados de cobre, rotor, eje, ventilador y dos rodamientos visibles. El acoplamiento tiene cubos metálicos y un elemento elástico; la bomba conserva su vista exterior de conjunto.

- Pulsa **Acercar motor** para observar el interior; **Ver conjunto** recupera el circuito completo.
- Ajusta **Opacidad** o selecciona **Exterior** para comparar la carcasa con el interior. Estos controles solo cambian la vista.
- Selecciona una pieza con el ratón, con Tab/Enter en la planta o en **Explorar interior**. El inspector describe su función; los canales se sincronizan con DE, NDE o carcasa según la pieza.
- El detalle ampliado muestra pistas, jaula y bolas del rodamiento DE o NDE. Su temperatura y RMS siguen siendo **superficiales y sintéticos**. No se ha agregado una temperatura real de bobina ni un sensor interno.
- Lubricación reducida dibuja un contacto naranja, contaminación añade partículas en los rodamientos, defecto impuesto añade una marca roja, desequilibrio muestra una masa excéntrica, desalineación resalta DE/acoplamiento, holgura señala pernos y ventilación reducida atenúa las líneas de aire. El calor rojo sigue la evolución térmica; no aparece instantáneamente por elegir una causa. La cavitación se representa en la bomba.

La geometría es ilustrativa y no está reconstruida del interior del motor fotografiado. La marca de defecto **no identifica una pista dañada real**: muestra una causa que tú impones. Las bolas y el rotor giran a una velocidad de dibujo legible; la vibración se amplifica. Sin datos nuevos, al pausar o al perder comunicación con el servicio, se detienen las animaciones y se retiran efectos y lecturas actuales. La preferencia de movimiento reducido también detiene el giro dibujado. La API, el modelo numérico y la ubicación de datos conservan su contrato 1.0.0.

Selecciona **DE**, **NDE**, **carcasa** o **bomba** en la planta o en sus tarjetas. Cambian los canales grandes y los gráficos. El paquete público incluye todas las zonas; sus dos canales principales son DE, el rodamiento próximo al acoplamiento.

| Acción | Qué observar |
| --- | --- |
| Agua · operación normal | Arranque hasta ~2.912 rpm, ~18 m³/h y ~45 m de altura. Temperatura desde ambiente, no un valor estable instantáneo. |
| Desalineación | RMS elevado, texto de condición y movimiento en DE/acoplamiento. También puedes mover el deslizador en mm. |
| Desequilibrio | Mayor componente a una vuelta en el motor; ajusta g·mm para comparar. |
| Lubricación insuficiente | Más ruido y fricción en los rodamientos; la temperatura sube con retraso. |
| Contaminación / defecto / fijación | Deslizadores independientes de contaminación del lubricante, intensidad de impulsos y holgura de base. El agua bombeada permanece limpia. |
| Calor visible | Selecciona **60×**, reduce ventilación a **5 %** y lubricación a **0 %**. Combínalo con desalineación y contaminación. En decenas de segundos, DE/carcasa se calientan y aparecen halos rojos. El tiempo exacto depende del estado inicial. |
| Cavitación | Selecciona el escenario o reduce NPSH disponible supuesto bajo 2,5 m. La bomba se mueve y baja su caudal. |
| Volver a normal | Restaura las causas, conserva la escala temporal y el calor acumulado. El RMS baja pronto; el enfriamiento tarda. No “repara” un rodamiento real. |
| Perder / restaurar señal | La planta continúa; los canales muestran **—** y `/api/latest` responde 503 mientras no exista una adquisición nueva. |
| Pausar / reanudar | Detiene/reanuda tiempo físico y adquisición. No muestra el paquete previo como actual. |
| Apagar / encender motor | Desacelera/enfría o arranca; sigue generando telemetría de sensores virtuales. |
| Exportar historial CSV | Descarga todas las zonas con unidades, origen, calidad, fechas UTC y reloj físico. |

Las referencias visuales **75 °C y 3 m/s² son ilustrativas**. Los colores y movimientos tienen texto equivalente. La amplitud y velocidad de animación están amplificadas para ser visibles: no representan desplazamiento real ni giro de ~2.900 rpm en la pantalla. Respeta la preferencia de movimiento reducido del sistema/navegador.

## Datos y reinicios

Por defecto: **`%LOCALAPPDATA%\MotorPumpTwin`**, fuera de esta carpeta, del portafolio y de OneDrive.

- `twin.sqlite3`: paquetes, hora local de recepción del servicio, estado físico, parámetros y registro de cambios de configuración/comandos. Conserva la identidad de instancia y la secuencia.
- `twin.sqlite3-wal` / `-shm`: archivos de SQLite mientras está abierto.
- `operacion.log`: errores y solicitudes; rotación de 2 MB con dos copias.
- `receiver-demo\receiver.sqlite3`: solo si ejecutas voluntariamente el receptor de ejemplo.

Los paquetes se conservan sin purga automática; revisa el tamaño para ensayos largos. Al volver a abrir, conserva temperaturas, rpm, tiempo físico y parámetros. **No simula las horas con el programa cerrado** ni reutiliza una lectura antigua como actual. Si estaba pausado o sin señal, conserva ese estado: pulsa Reanudar o Restaurar señal. La URL opcional puede conservarse, pero **el envío HTTP siempre vuelve desactivado**. Copia la base para respaldarla después de cerrar la aplicación. `.gitignore` excluye bases, registros, entorno y datos de prueba.

## Conectar cuando tú decidas

Puedes consultar REST, escuchar SSE o importar CSV desde cualquier software local. No hay conexión automática ni adaptador exclusivo de neiron. El simulador sirve solo en 127.0.0.1 y no abre el ESP32, Wi-Fi, una red industrial ni servicios externos.

**Consultar con Python**, desde esta carpeta:

```powershell
.\.venv\Scripts\python.exe examples\read_latest.py
```

**Probar envío voluntario**, en otra consola:

```powershell
.\.venv\Scripts\python.exe examples\receiver.py
```

En la vista **Conexiones**, escribe `http://127.0.0.1:9000/telemetry` y pulsa **Activar envío**. El receptor devuelve 201 al guardar; rechaza inválidos con 400 y duplicados/fuera de orden con 409. Consulta `http://127.0.0.1:9000/status` para ver cuántos aceptó. **Desconectar** detiene la salida sin detener la planta. Una solicitud ya en curso puede finalizar al desconectar; no empiezan nuevas. Ctrl+C cierra el receptor de ejemplo.

El receptor se proporciona como ejemplo editable: no se inicia con el simulador. Adapta el receptor de tu software al contrato documentado en [API.md](API.md). Los contratos antiguos de neiron no son intercambiables directamente; una futura integración requiere un adaptador explícito.

## Editar y verificar

Abre esta carpeta en VSCode y elige `.venv\Scripts\python.exe` como intérprete. No hay compilación ni dependencias de frontend. Cambios en Python requieren reiniciar; cambios en HTML/CSS/JS se ven al recargar la página.

| Módulo | Responsabilidad |
| --- | --- |
| `twin/model.py` | Motor, bomba, calor, parámetros y aceleración sintética de cuatro zonas. |
| `twin/contract.py` | Contrato público y validación de telemetría generada. |
| `twin/storage.py` | SQLite, estado, historial y eventos. |
| `twin/engine.py` | Reloj, adquisición y controles. |
| `twin/transport.py` | Salida HTTP opcional en un hilo separado. |
| `twin/server.py` | Servicio local REST/SSE/CSV y archivos de interfaz. |
| `twin/static/` | Interfaz española, dibujo SVG y gráficos Canvas, todo local. |
| `examples/` | Cliente y receptor genéricos reutilizables. |

Ejecuta `probar.bat` o `.venv\Scripts\python.exe -m unittest discover -s tests -v`. Las pruebas usan bases temporales. El recorrido real de Edge está en `tests/browser.cjs`; requiere las herramientas de desarrollo indicadas en [VERIFICACION.md](VERIFICACION.md), que distingue esas pruebas del uso normal.

El detalle de supuestos físicos y sus referencias está en [MODELO.md](MODELO.md). Pendientes: placa real del motor, curva de bomba, geometría de rodamientos, sensor/fijación/filtros reales y calibración; después se puede desarrollar firmware e integración física. No existe predicción de fallas, vida útil ni diagnóstico validado.
