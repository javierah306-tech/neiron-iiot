@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto verify
where py >nul 2>nul
if not errorlevel 1 (
    py -3.12 -m venv --without-pip .venv
    if not errorlevel 1 goto verify
)
where python >nul 2>nul
if not errorlevel 1 (
    python -c "import sys; assert sys.version_info[:2] == (3,12)" >nul 2>nul
    if not errorlevel 1 (
        python -m venv --without-pip .venv
        if not errorlevel 1 goto verify
    )
)
set "TWIN_PY=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%TWIN_PY%" (
    "%TWIN_PY%" -m venv --without-pip .venv
    if not errorlevel 1 goto verify
)
echo No se encontro Python 3.12. Instale Python 3.12 para su usuario y vuelva a ejecutar.
echo No se instalaron paquetes ni se cambio la configuracion del sistema.
pause
exit /b 1
:verify
.venv\Scripts\python.exe -c "import sys,sqlite3; assert sys.version_info[:2] == (3,12); print('Entorno propio listo. Python',sys.version.split()[0],'- SQLite',sqlite3.sqlite_version)"
if errorlevel 1 (
    echo El entorno existente necesita Python 3.12. Consulte README.md.
    pause
    exit /b 1
)
echo Sin paquetes externos ni internet necesario. Abra iniciar.bat.
exit /b 0
