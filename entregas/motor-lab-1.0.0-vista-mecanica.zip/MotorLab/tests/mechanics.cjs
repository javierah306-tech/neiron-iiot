// Ensayo de integración visual. Edge/Playwright solo se usan en desarrollo.
const fs = require('fs'), path = require('path'), net = require('net');
const assert = require('assert/strict'), {spawn} = require('child_process');
const {chromium} = require(process.env.TWIN_PLAYWRIGHT || 'playwright');
const root = path.resolve(__dirname, '..');
const artifacts = path.join(root, '.test-artifacts', 'mechanics');
const run = path.join(root, '.test-artifacts', 'mechanics-run-' + Date.now());
fs.mkdirSync(artifacts, {recursive: true}); fs.mkdirSync(run, {recursive: true});
let server, browser, url;
const report = {started: new Date().toISOString(), checks: [], errors: [], externalRequests: [], testDataDirectory: run};
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
async function until(fn, label, ms = 12000) {
    const end = Date.now() + ms;
    while (Date.now() < end) {if (await fn()) return; await delay(200);}
    throw Error('Tiempo agotado: ' + label);
}
function check(label) {report.checks.push(label); console.log('OK:', label);}
const freePort = () => new Promise(resolve => {
    const s = net.createServer(); s.listen(0, '127.0.0.1', () => {const p = s.address().port; s.close(() => resolve(p));});
});
async function get() {return (await fetch(url + '/api/status')).json();}
async function post(route, payload) {
    const response = await fetch(url + route, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)});
    assert(response.ok, await response.text());
}
async function slider(page, id, value) {
    await page.locator('#' + id).evaluate((el, v) => {
        el.value = v; el.dispatchEvent(new Event('input', {bubbles: true})); el.dispatchEvent(new Event('change', {bubbles: true}));
    }, value);
    await until(async () => (await get()).settings[id] === value, id);
}
async function motionValue(page) {return page.locator('#rotor-bars path').first().getAttribute('d');}
(async () => {
    try {
        url = 'http://127.0.0.1:' + await freePort();
        server = spawn(path.join(root, '.venv', 'Scripts', 'python.exe'), ['-m', 'twin.server', '--port', url.split(':').pop(), '--data-dir', run], {cwd: root, windowsHide: true, env: {...process.env, PYTHONUTF8: '1'}});
        let log = ''; server.stdout.on('data', v => log += v); server.stderr.on('data', v => log += v);
        await until(async () => {if (server.exitCode !== null) throw Error(log); try {return !!(await get()).current;} catch {return false;}}, 'servidor y adquisición');
        browser = await chromium.launch({executablePath: process.env.TWIN_EDGE || 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true});
        const context = await browser.newContext({viewport: {width: 1536, height: 1200}});
        await context.route('**/*', route => {const u = route.request().url(); if (u.startsWith(url + '/')) route.continue(); else {report.externalRequests.push(u); route.abort();}});
        const page = await context.newPage(); page.on('pageerror', error => report.errors.push(error.message));
        await page.goto(url);
        await until(async () => (await page.locator('#temperature').textContent()) !== '—', 'lecturas');
        assert.equal(await page.locator('#view-transparent').getAttribute('aria-pressed'), 'true');
        assert.equal(await page.locator('[data-part]').count(), 7);
        assert.equal(await page.locator('#balls-de ellipse').count(), 8);
        assert.equal(await page.locator('#detail-balls circle').count(), 8);
        assert.equal(await page.locator('#component-select option').count(), 7);
        check('Inicio local, cuatro canales y siete componentes mecánicos con carcasa translúcida');
        const bar1 = await motionValue(page); await delay(600); assert.notEqual(await motionValue(page), bar1);
        const ball1 = await page.locator('#balls-de ellipse').first().getAttribute('cy'); await delay(400); assert.notEqual(await page.locator('#balls-de ellipse').first().getAttribute('cy'), ball1);
        check('Rotor y bolas del rodamiento se mueven con proyección sobre el eje horizontal');
        await page.screenshot({path: path.join(artifacts, '01-conjunto.png')});
        await page.click('#motor-focus'); assert.equal(await page.locator('#motor-focus').getAttribute('aria-pressed'), 'true');
        await page.selectOption('#component-select', 'rotor'); assert((await page.locator('#component-title').textContent()).includes('Rotor'));
        await page.locator('#visual-nde').focus(); await page.keyboard.press('Enter');
        assert((await page.locator('#component-title').textContent()).includes('NDE'));
        assert((await page.locator('#selected-title').textContent()).includes('NDE'));
        assert.equal(await page.locator('#visual-nde').evaluate(el => getComputedStyle(el).outlineStyle), 'none');
        await page.selectOption('#component-select', 'de');
        await page.screenshot({path: path.join(artifacts, '02-interior.png')});
        check('Acercamiento al motor, selección de componentes y teclado sincronizados con los sensores');
        await page.locator('#shell-opacity').evaluate(el => {el.value = '55'; el.dispatchEvent(new Event('input', {bubbles:true}));});
        await until(() => page.locator('#motor-shell').evaluate(el => Number(getComputedStyle(el).opacity) === .55), 'opacidad regulable');
        await page.click('#view-exterior'); assert(await page.locator('#shell-opacity').isDisabled());
        await until(() => page.locator('#motor-shell').evaluate(el => Number(getComputedStyle(el).opacity) === 1), 'acabado opaco');
        await page.screenshot({path: path.join(artifacts, '03-exterior.png')});
        await page.click('#view-transparent'); await page.locator('#shell-opacity').evaluate(el => {el.value = '15'; el.dispatchEvent(new Event('input', {bubbles:true}));});
        check('Opacidad regulable y alternancia funcional entre acabado exterior e interior');
        for (const [preset, marker] of [['alignment', 'cause-alignment'], ['imbalance', 'cause-imbalance'], ['lubrication', 'cause-lubrication'], ['bearing', 'cause-bearing'], ['cooling', 'cause-cooling'], ['cavitation', 'cause-cavitation']]) {
            await page.selectOption('#preset', 'normal'); await page.click('#apply-preset');
            await page.selectOption('#preset', preset); await page.click('#apply-preset');
            await until(() => page.locator('#stage').evaluate((el, m) => el.classList.contains(m), marker), preset);
            assert(await page.locator('#mechanical-effects strong').count() >= 1);
            if (preset === 'alignment') {
                await until(() => page.locator('#visual-de').evaluate(el => el.classList.contains('shaking')), 'vibración en DE');
                assert(await page.locator('#alignment-force').evaluate(el => Number(getComputedStyle(el).opacity) > 0));
            }
            if (preset === 'cavitation') {
                assert(await page.locator('#pump-bubbles').evaluate(el => Number(getComputedStyle(el).opacity) > 0));
                assert.equal(await page.locator('#detail-defect').evaluate(el => Number(getComputedStyle(el).opacity)), 0);
            }
        }
        await slider(page, 'contamination_pct', 80); await slider(page, 'looseness_pct', 70);
        await until(() => page.locator('#stage').evaluate(el => el.classList.contains('cause-contamination') && el.classList.contains('cause-looseness')), 'contaminación y holgura');
        check('Ocho causas localizadas: fricción, partículas, defecto, desalineación, masa excéntrica, fijación, aire y cavitación');
        await page.selectOption('#preset', 'normal'); await page.click('#apply-preset');
        await page.selectOption('#time-scale', '60'); await slider(page, 'cooling_pct', 5); await slider(page, 'lubrication_pct', 0);
        await slider(page, 'contamination_pct', 80); await slider(page, 'misalignment_mm', 1.1);
        await until(async () => (await get()).current?.zones.de.temperature_c > 75, 'calor en DE', 55000);
        await until(() => page.locator('#detail-heat').evaluate(el => Number(getComputedStyle(el).opacity) > .4), 'detalle térmico rojo');
        await page.screenshot({path: path.join(artifacts, '04-anomalias.png')});
        check('Calor gradual en rodamiento DE, rojo en detalle/interior y vibración local con texto explicativo');
        await page.click('#signal-toggle');
        await until(() => page.locator('#detail-signal').evaluate(el => el.textContent.includes('sin datos actuales')), 'sin señal');
        assert.equal(await page.locator('#temperature').textContent(), '—');
        const stopped = await motionValue(page); await delay(700); assert.equal(await motionValue(page), stopped);
        assert.equal(await page.locator('#detail-heat').evaluate(el => Number(getComputedStyle(el).opacity)), 0);
        assert.equal(await page.locator('#mechanical-effects strong').count(), 0);
        check('Pérdida de señal quita lecturas/efectos actuales y detiene toda rotación sin reutilizar paquetes');
        await page.click('#signal-toggle'); await until(async () => (await page.locator('#temperature').textContent()) !== '—', 'recepción restaurada');
        await page.click('#pause'); await until(() => page.locator('#stage').evaluate(el => el.classList.contains('stale')), 'pausa');
        const paused = await motionValue(page); await delay(600); assert.equal(await motionValue(page), paused);
        await page.click('#pause'); await until(async () => (await page.locator('#temperature').textContent()) !== '—', 'reanudar');
        check('Pausa/reanudación y recuperación de telemetría restauran las animaciones con datos nuevos');
        await page.selectOption('#preset', 'normal'); await page.click('#apply-preset');
        await until(async () => await page.locator('#mechanical-effects strong').count() === 0, 'normal');
        assert((await page.locator('#mechanical-effects').textContent()).includes('calor residual'));
        await page.emulateMedia({reducedMotion: 'reduce'}); await delay(300);
        const quiet = await motionValue(page); await delay(900); assert.equal(await motionValue(page), quiet);
        assert.equal(await page.locator('#air-streams').evaluate(el => getComputedStyle(el).animationName), 'none');
        check('Recuperación conserva inercia térmica y movimiento reducido detiene la animación mecánica');
        await page.setViewportSize({width: 390, height: 844});
        assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
        await page.screenshot({path: path.join(artifacts, '05-movil.png'), fullPage: true});
        await page.evaluate(() => window.scrollTo(0, 0));
        await page.screenshot({path: path.join(artifacts, '06-movil-vista.png')});
        assert.deepEqual(report.errors, []); assert.deepEqual(report.externalRequests, []);
        check('390 px sin desbordamiento; sin errores JavaScript, solicitudes externas ni nuevas dependencias');
        report.result = 'passed';
    } catch (error) {
        report.result = 'failed'; report.error = error.stack; console.error(error); process.exitCode = 1;
    } finally {
        if (browser) await browser.close();
        if (server && server.exitCode === null) {
            try {await post('/api/shutdown', {confirm: true}); await until(() => server.exitCode !== null, 'cierre', 6000);} catch {server.kill();}
        }
        report.finished = new Date().toISOString();
        fs.writeFileSync(path.join(artifacts, 'report.json'), JSON.stringify(report, null, 2));
        console.log('Informe:', path.join(artifacts, 'report.json'));
    }
})();
