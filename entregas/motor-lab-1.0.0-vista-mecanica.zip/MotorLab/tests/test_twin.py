import copy
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
import csv
from http.client import HTTPConnection
import io
import json
import math
from pathlib import Path
import sys
import tempfile
from threading import Thread
import unittest
from unittest.mock import patch

from twin.model import Plant, Settings, ZONES
from twin.contract import build_packet, validate, stamp
from twin.storage import Storage
from twin.engine import Engine
from twin.transport import Sender, validate_target
from twin.server import Server
from examples.receiver import Receiver

class PhysicalModelTests(unittest.TestCase):
    def steady(self, plant=None, seconds=6000):
        plant=plant or Plant()
        plant.settings=plant.settings.updated({"time_scale":60})
        for _ in range(seconds//60):plant.step(1)
        plant.acquire(1)
        return plant
    def test_normal_water_reference_and_energy_balance(self):
        p=self.steady();c=p.context
        self.assertAlmostEqual(c["rpm"],2910,delta=15)
        self.assertAlmostEqual(c["flow_m3h"],18,delta=.1)
        self.assertAlmostEqual(c["head_m"],45,delta=.2)
        self.assertLess(c["hydraulic_power_w"],c["pump_shaft_w"])
        self.assertAlmostEqual(c["electrical_power_w"],c["pump_shaft_w"]+c["motor_losses_w"]+c["bearing_friction_w"])
        self.assertTrue(45<p.temperatures["casing"]<65)
        self.assertTrue(30<p.temperatures["de"]<50)
        self.assertTrue(.5<p.zones["de"]["vibration_rms_m_s2"]<1)
    def test_rms_matches_analytic_three_axis_signal_without_dc(self):
        p=Plant();p.rpm=3000
        with patch("random.Random.gauss",return_value=0):z=p.acquire(1)["de"]
        r=3000/2910;load=p.hydraulics(3000)["pump_load"]
        a=(.55+.2*load)*r*r;b=.14*r*r;c=.2*r*r;e=.2*r
        expected=math.sqrt(.5*(a*a*1.7625+b*b*1.6125+c*c*.4525+e*e)+b*.35*e*math.cos(.2))
        self.assertAlmostEqual(z["vibration_rms_m_s2"],expected,places=5)
        p.phase=0
        with patch("random.Random.gauss",return_value=8):offset=p.acquire(1)["de"]
        self.assertAlmostEqual(z["vibration_rms_m_s2"],offset["vibration_rms_m_s2"],places=5)
    def test_bearing_causal_controls_change_zone_signals(self):
        for key,value in (("lubrication_pct",0),("contamination_pct",100),("misalignment_mm",1.5),("imbalance_gmm",400),("looseness_pct",100),("bearing_defect_pct",100)):
            with self.subTest(key=key):
                normal=self.steady(seconds=1200);baseline=normal.zones["de"]["vibration_rms_m_s2"]
                normal.settings=normal.settings.updated({key:value})
                normal.acquire(2)
                self.assertGreater(normal.zones["de"]["vibration_rms_m_s2"],baseline*1.4)
    def test_heat_inertia_recovery_and_zone_locality(self):
        p=self.steady();before=p.temperatures.copy()
        p.settings=p.settings.updated({"cooling_pct":5,"lubrication_pct":0,"contamination_pct":70,"misalignment_mm":1})
        self.assertEqual(p.temperatures,before)
        self.steady(p,2400)
        self.assertGreater(p.temperatures["de"],75)
        self.assertGreater(p.temperatures["casing"],100)
        self.assertLess(p.temperatures["pump"],30)
        hot=p.temperatures.copy();p.settings=Settings(time_scale=60)
        self.assertEqual(p.temperatures,hot)
        self.steady(p,1200)
        self.assertLess(p.temperatures["de"],hot["de"])
        self.assertLess(p.temperatures["casing"],hot["casing"])
    def test_thermal_nodes_conserve_injected_energy(self):
        p=self.steady();p.settings=p.settings.updated({"time_scale":1,"lubrication_pct":0,"cooling_pct":30})
        old=p.temperatures.copy();p.step(1);s=p.settings;c=p.context;r=min(1.15,p.rpm/2910)
        capacities={"casing":16000,"de":2400,"nde":1800,"pump":6000}
        stored=sum(capacities[k]*(p.temperatures[k]-old[k]) for k in old)
        injected=c["motor_losses_w"]+c["bearing_friction_w"]+c["pump_shaft_w"]-c["hydraulic_power_w"]
        dissipated=18.18*(.35+.65*r)*s.cooling_pct/100*(old["casing"]-s.ambient_c)
        dissipated+=sum(2.5*(old[k]-s.ambient_c) for k in ("de","nde"))
        dissipated+=(35+18*c["flow_m3h"])*(old["pump"]-s.water_c)
        self.assertAlmostEqual(stored,injected-dissipated,places=7)
    def test_water_valve_and_suction_affect_pump(self):
        p=self.steady(seconds=600);nom=p.hydraulics(p.rpm)
        p.settings=p.settings.updated({"valve_pct":50})
        self.assertLess(p.hydraulics(p.rpm)["flow_m3h"],nom["flow_m3h"])
        p.settings=p.settings.updated({"valve_pct":100,"suction_margin_m":.5});p.acquire(2)
        self.assertLess(p.hydraulics(p.rpm)["flow_m3h"],nom["flow_m3h"])
        self.assertGreater(p.zones["pump"]["vibration_rms_m_s2"],3)
    def test_stop_decelerates_cools_and_retains_telemetry(self):
        p=self.steady();hot=p.temperatures["casing"];p.motor_on=False
        self.steady(p,1200)
        self.assertLess(p.rpm,.01)
        self.assertLess(p.temperatures["casing"],hot)
        self.assertLess(p.zones["de"]["vibration_rms_m_s2"],.05)
    def test_probe_resolution_and_saturation_are_explicit(self):
        p=Plant();p.probes["de"]=180
        z=p.acquire(1)
        self.assertEqual(z["de"]["quality"],"saturated")
        self.assertEqual(z["de"]["temperature_c"],125)
        for v in z.values():self.assertEqual(v["temperature_c"]*16,round(v["temperature_c"]*16))
    def test_invalid_parameters_and_nonfinite_steps_rejected(self):
        for raw in ({"foo":1},{"lubrication_pct":-1},{"ambient_c":True},{"ambient_c":float("nan")},{"time_scale":12},{"misalignment_mm":9}):
            with self.subTest(raw=raw),self.assertRaises(ValueError):Settings().updated(raw)
        for dt in (float("inf"),-1,6):
            with self.assertRaises(ValueError):Plant().step(dt)

class EngineTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix="twin-test-")
        self.store=Storage(self.temp.name)
        self.now=0
        self.engine=Engine(self.store,monotonic=lambda:self.now)
    def tearDown(self):self.store.close();self.temp.cleanup()
    def test_packet_contract_and_clock_separation(self):
        self.engine.configure({"time_scale":60});self.engine.tick(1)
        p=self.engine.status()["current"]
        self.assertEqual(p["simulation_time_s"],60)
        self.assertEqual(p["vibration"]["samples_per_axis"],1000)
        self.assertEqual(p["vibration"]["sample_rate_hz"],1000)
        self.assertEqual(p["source"],"simulated")
        self.assertTrue(p["acquired_at"].endswith("Z"))
        self.assertNotIn("received_at",p)
        self.assertIn("received_at",self.store.history()[0])
        bad=copy.deepcopy(p);bad["zones"]["de"]["temperature_c"]=float("nan")
        with self.assertRaises(ValueError):validate(bad)
        bad=copy.deepcopy(p);bad["schema_version"]=True
        with self.assertRaises(ValueError):validate(bad)
    def test_pause_loss_and_stale_never_expose_old_as_current(self):
        e=self.engine;e.tick();self.now=5
        self.assertIsNone(e.status()["current"])
        self.now=6;e.tick();e.command("pause");elapsed=e.plant.elapsed_s;e.tick()
        self.assertEqual(e.plant.elapsed_s,elapsed)
        self.assertIsNone(e.status()["current"])
        e.command("resume");e.tick();sequence=e.sequence;e.command("signal_loss");e.tick()
        self.assertGreater(e.plant.elapsed_s,elapsed)
        self.assertEqual(e.sequence,sequence)
        self.assertIsNone(e.status()["current"])
        e.command("signal_restore");e.tick()
        self.assertGreater(e.status()["current"]["sequence"],sequence)
    def test_restart_persists_physics_history_but_disables_push(self):
        e=self.engine;e.configure({"time_scale":60,"lubrication_pct":20});e.tick()
        e.integration_configure("http://127.0.0.1:9000/telemetry",True)
        temp=e.plant.temperatures.copy();sequence=e.sequence
        self.store.close();self.store=Storage(self.temp.name);restored=Engine(self.store)
        self.assertEqual(restored.sequence,sequence)
        self.assertEqual(restored.plant.temperatures,temp)
        self.assertEqual(restored.plant.settings.lubrication_pct,20)
        self.assertFalse(restored.integration["enabled"])
        self.assertEqual(self.store.count(),1)
        self.assertIsNone(restored.status()["current"])
        restored.tick();self.assertEqual(restored.sequence,sequence+1)
    def test_duplicates_and_out_of_order_not_saved(self):
        e=self.engine;e.tick();p=e.latest
        with self.assertRaises(ValueError):self.store.save(e.saved(),p)
        later=copy.deepcopy(p);later["sequence"]=3;self.store.save(e.saved(),later)
        older=copy.deepcopy(p);older["sequence"]=2
        with self.assertRaises(ValueError):self.store.save(e.saved(),older)
        self.assertEqual(self.store.count(),2)
    def test_normal_restores_causes_without_resetting_heat(self):
        e=self.engine;e.configure({"lubrication_pct":0,"cooling_pct":5,"time_scale":60})
        e.tick();hot=e.plant.temperatures.copy();e.command("normal")
        self.assertEqual(e.plant.temperatures,hot)
        self.assertEqual(e.plant.settings.lubrication_pct,100)
        self.assertEqual(e.plant.settings.time_scale,60)
    def test_generic_sender_opt_in_and_once_per_new_packet(self):
        receiver=Receiver(("127.0.0.1",0),Path(self.temp.name)/"receiver")
        t=Thread(target=receiver.serve_forever,daemon=True);t.start()
        sender=Sender(self.engine);self.engine.tick();sender.tick()
        self.assertEqual(self.engine.integration["sent"],0)
        self.engine.integration_configure(f"http://127.0.0.1:{receiver.server_address[1]}/telemetry",True)
        try:
            sender.tick();sender.tick()
            self.assertEqual(self.engine.integration["sent"],1)
            self.engine.tick();sender.tick();self.assertEqual(self.engine.integration["sent"],2)
            self.engine.integration_configure(self.engine.integration["url"],False)
            self.engine.tick();sender.tick();self.assertEqual(self.engine.integration["sent"],2)
        finally:receiver.shutdown();receiver.server_close();receiver.db.close();t.join()
    def test_external_endpoints_blocked_and_receptor_failure_does_not_stop_model(self):
        for target in ("https://127.0.0.1/a","http://example.com/a","http://127.0.0.1@evil.com/a","http://127.0.0.1:2/a#frag","http://192.168.0.2/a"):
            with self.assertRaises(ValueError):validate_target(target)
        self.engine.integration_configure("http://127.0.0.1:1/telemetry",True)
        self.engine.tick();Sender(self.engine).tick()
        self.assertEqual(self.engine.integration["state"],"unavailable")
        self.engine.tick();self.assertEqual(self.engine.sequence,2)

class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix="twin-http-")
        self.store=Storage(self.temp.name);self.engine=Engine(self.store)
        self.server=Server(("127.0.0.1",0),self.engine)
        self.thread=Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.port=self.server.server_address[1]
    def tearDown(self):
        self.server.stop_event.set();self.server.shutdown();self.server.server_close();self.thread.join();self.store.close();self.temp.cleanup()
    def request(self,path,body=None,headers=None):
        c=HTTPConnection("127.0.0.1",self.port,timeout=3)
        h=headers or {}
        if body is not None:h={"Content-Type":"application/json",**h}
        c.request("POST" if body is not None else "GET",path,json.dumps(body) if body is not None else None,h)
        r=c.getresponse();raw=r.read();status=r.status;c.close()
        return status,raw
    def test_local_start_static_offline_and_no_neiron_import(self):
        status,raw=self.request("/");self.assertEqual(status,200)
        self.assertIn("DATOS SIMULADOS",raw.decode())
        self.assertNotIn("cdn.",raw.decode())
        self.assertFalse(any(k=="neiron" or k.startswith("neiron.") for k in sys.modules))
        self.assertFalse(self.engine.integration["enabled"])
        for path in ("/app.js","/app.css","/api/meta","/api/status"):self.assertEqual(self.request(path)[0],200)
    def test_http_controls_validation_and_fresh_latest(self):
        self.assertEqual(self.request("/api/latest")[0],503)
        self.engine.tick();self.assertEqual(self.request("/api/latest")[0],200)
        self.assertEqual(self.request("/api/control",{"action":"pause"})[0],200)
        self.assertEqual(self.request("/api/latest")[0],503)
        self.assertEqual(self.request("/api/parameters",{"ambient_c":float("nan")})[0],400)
        self.assertEqual(self.request("/api/parameters",{"unknown":1})[0],400)
        self.assertEqual(self.request("/api/integration",{"url":"http://example.com/a","enabled":True})[0],400)
    def test_host_origin_guards(self):
        self.assertEqual(self.request("/api/status",headers={"Host":"evil.test"})[0],403)
        self.assertEqual(self.request("/api/control",{"action":"pause"},{"Origin":"https://evil.test"})[0],403)
        self.assertTrue(self.engine.running)
    def test_opening_from_external_link_allows_document_but_keeps_api_guarded(self):
        headers={"Sec-Fetch-Site":"cross-site","Sec-Fetch-Mode":"navigate","Sec-Fetch-Dest":"document"}
        self.assertEqual(self.request("/",headers=headers)[0],200)
        self.assertEqual(self.request("/api/status",headers=headers)[0],403)
        self.assertEqual(self.request("/api/control",{"action":"pause"},headers)[0],403)
        self.assertTrue(self.engine.running)
    def test_launcher_recognizes_only_this_application_and_closes_gracefully(self):
        from twin.launcher import running, stop
        self.assertTrue(running(self.port))
        self.assertEqual(stop(self.port),0)
        self.thread.join(timeout=3)
        self.assertFalse(self.thread.is_alive())
    def test_history_csv_units_origin_dates_and_ranges(self):
        self.engine.tick();self.engine.tick()
        status,raw=self.request("/api/export.csv");self.assertEqual(status,200)
        rows=list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig")),delimiter=";"))
        self.assertEqual(len(rows),2)
        for row in rows:
            self.assertEqual(row["source"],"simulated")
            self.assertEqual(row["temperature_unit"],"degC")
            self.assertEqual(row["vibration_unit"],"m/s2")
            self.assertTrue(row["received_at_utc"].endswith("Z"))
        self.assertEqual(self.request("/api/history?from=2026-01-01T00:00:00")[0],400)
        self.assertEqual(len(json.loads(self.request("/api/history?limit=1")[1])["rows"]),1)
    def test_sse_stream_and_loss_status(self):
        self.engine.tick()
        c=HTTPConnection("127.0.0.1",self.port,timeout=3);c.request("GET","/api/stream");r=c.getresponse()
        lines=[r.readline().decode() for _ in range(7)]
        self.assertEqual(r.status,200)
        self.assertIn("event: telemetry\n",lines)
        packetline=next(line for line in lines if line.startswith("data: {") and "schema" in line)
        self.assertEqual(json.loads(packetline[6:])["source"],"simulated")
        self.engine.command("signal_loss")
        while True:
            line=r.readline().decode()
            if "signal_loss" in line:break
        c.close()

if __name__=="__main__":unittest.main()
