# Contrato e integración local

Sin SDK, cuentas ni dependencias. HTTP en `127.0.0.1:8766` por defecto. JSON UTF-8; todos los valores numéricos son finitos. El servicio valida Host y origen, no habilita CORS general. Para conectar una web en otro puerto, su backend consulta la API o recibe POST: no se debe desactivar la protección del navegador.

## Interfaces públicas

| Método y ruta | Respuesta / efecto |
| --- | --- |
| `GET /api/latest` | Paquete actual, 200. Sin lectura vigente, 503 con estado; nunca devuelve un paquete histórico como actual. |
| `GET /api/stream` | Server-Sent Events: `telemetry`, `status` y comentarios heartbeat. Máximo cuatro flujos. |
| `GET /api/history?limit=600` | `{rows:[...]}` cronológico, hasta 1.000 paquetes recientes; incluye `received_at`. |
| `GET /api/export.csv` | Todos los paquetes del intervalo, UTF-8 BOM, separador `;`, unidades/fechas/origen explícitos. |
| `GET /api/status` | Estado de planta, ajustes, canales, gráficos y envío opcional. |
| `GET /api/meta` | Zonas, campos, rangos, unidades, ayuda y escenarios. |
| `POST /api/parameters` | Cambios parciales, por ejemplo `{"lubrication_pct":20,"time_scale":60}`. |
| `POST /api/control` | `{"action":"pause"}`, `resume`, `motor_on`, `motor_off`, `signal_loss`, `signal_restore` o clave de escenario. |
| `POST /api/integration` | `{"url":"http://127.0.0.1:9000/telemetry","enabled":true}`. Solo destino HTTP local; explícito, sin redirecciones. |
| `POST /api/shutdown` | `{"confirm":true}` solicita guardar y cerrar el servicio. Lo usa el archivo de cierre; mantiene la validación de Host/Origin. |

Historial y CSV admiten `from` y `to` con instantes ISO 8601 que incluyan zona; codifica `+` como `%2B` si usas un offset. Ejemplo: `?from=2026-10-01T00:00:00Z&to=2026-10-02T03:00:00Z`. Fechas internas/CSV en UTC; la interfaz usa `America/Santiago` mediante Intl, incluyendo horario de verano. No se interpretan fechas sin zona.

Paquetes aproximadamente cada segundo de **reloj real**, con 1.000 muestras sintéticas por eje en una ventana de 1 s. Acelerar tiempo físico no aumenta frecuencia de publicación, fs ni longitud de ventana. `simulation_time_s` es tiempo acumulado de la planta; `acquired_at` es hora del PC, no una fecha acelerada.

## Esquema `motor-pump-twin.telemetry`, versión 1

```json
{
  "schema": "motor-pump-twin.telemetry",
  "schema_version": 1,
  "instance_id": "UUID persistente de esta instalación/base",
  "device_id": "virtual-sensors-01",
  "asset_id": "motor-pump-5hp",
  "sequence": 123,
  "acquired_at": "2026-10-01T20:00:00.000Z",
  "source": "simulated",
  "quality": "synthetic",
  "config_revision": 8,
  "simulation_time_s": 7380,
  "time_scale": 60,
  "temperature": {
    "value": 39.375,
    "unit": "degC",
    "location": "de",
    "method": "synthetic_contact_probe_12bit"
  },
  "vibration": {
    "value": 0.730689,
    "unit": "m/s2",
    "location": "de",
    "method": "synthetic_vector_acceleration_rms_dc_removed",
    "sample_rate_hz": 1000,
    "window_s": 1,
    "samples_per_axis": 1000
  },
  "zones": {},
  "context": {}
}
```

El ejemplo abrevia `zones` y `context`; un paquete real del simulador contiene siempre las cuatro zonas. Cada zona `nde`, `casing`, `de`, `pump` incluye `name`, `temperature_c`, `vibration_rms_m_s2`, `rms_axes_m_s2` (X/Y/Z) y `quality`. `context` contiene magnitudes con unidad en su nombre: `rpm`, `flow_m3h`, `head_m`, `pressure_bar`, `hydraulic_power_w`, `pump_shaft_w`, `bearing_friction_w`, `motor_losses_w`, `electrical_power_w`, `motor_load_pct`; además índices ilustrativos y rendimiento.

`source` nunca cambia a `real`. `quality` es `synthetic` o `saturated`: saturación térmica a -55/125 °C de la sonda emulada. No es una lectura de ESP32. No se entrega velocidad en mm/s, diagnóstico BPFO/BPFI ni porcentaje de vida útil. No hay recepción de paquetes de hardware en esta app.

`received_at` lo asigna **cada receptor** con su propio reloj UTC. La base local lo añade cuando guarda y lo presenta en historial/CSV. Los POST salientes incluyen `acquired_at`; el receptor de ejemplo guarda `received_at` por separado y devuelve ese instante en su acuse. No se fabrica una hora de recepción remota.

## Reglas para un consumidor

- Identidad idempotente: `(instance_id, sequence)`. La secuencia persiste al reiniciar; otra base crea otra instancia. No deduzcas duplicados solo por hora.
- Valida esquema/versión, origen, identidad, tipos/rangos, unidades, calidad e instantes con zona. No conviertas `simulated` en `real`.
- Rechaza duplicados y secuencias inferiores; registra la causa. No reordena automáticamente la serie. Para productores/receptores distribuidos futuros se deberán definir tolerancias de reloj y sincronización.
- El receptor de ejemplo acepta paquetes de hasta 5 s de antigüedad y 5 s de adelanto; rechaza fechas de adquisición retrocedidas respecto de la anterior. Estos valores son de laboratorio local.
- Trata como ausente el flujo sin paquetes durante varios segundos. Un `503` o evento `status` exige retirar los valores actuales; el historial puede seguir visible, identificado.

SSE solo entrega el paquete actual al abrir y los nuevos durante la conexión. `id` es la secuencia; no reproduce historial por `Last-Event-ID`. Consulta `/api/history` para recuperar un intervalo. Pausa/pérdida de señal emiten estado y mantienen heartbeat, sin retransmitir lecturas antiguas.

La salida POST guarda un solo intento por secuencia y sesión de envío. Un receptor lento/no disponible no bloquea el hilo de física. No hay cola de retransmisión histórica. Tras desconectar o reiniciar, no se inician envíos hasta una activación explícita; una petición ya en curso puede finalizar. Aceptación HTTP 2xx indica acuse del receptor, no verificación de su persistencia ni conexión de hardware.

## Cliente Python mínimo

```python
import json
from urllib.request import build_opener, ProxyHandler
opener = build_opener(ProxyHandler({}))
with opener.open("http://127.0.0.1:8766/api/latest", timeout=3) as response:
    packet = json.load(response)
print(packet["source"], packet["temperature"], packet["vibration"])
```

Para SSE, `urllib.request.urlopen` puede leer líneas `event:` / `data:` hasta una línea vacía; el JSON de `telemetry` tiene el mismo contrato. El ejemplo `read_latest.py` maneja 503 y errores de conexión. `receiver.py` es una aplicación independiente que demuestra validación, persistencia e idempotencia.
