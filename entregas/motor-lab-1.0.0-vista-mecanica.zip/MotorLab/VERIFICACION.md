# Verificación local · Motor / Lab 1.0.0

Entorno: Windows, CPython 3.12.14 en `.venv` propio, SQLite 3.53.1. IA desactivada, sin hardware y sin servicios externos. Se usaron exclusivamente bases temporales; no se modificaron datos de operación de neiron ni su entorno.

## Pruebas del modelo, servicio y persistencia

Comando ejecutado:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

**21 pruebas aprobadas**, con carpetas temporales de `tempfile.TemporaryDirectory` y cierre de conexiones al terminar:

- Punto de operación nominal agua/motor y balance de potencia.
- Conservación de energía en los cuatro nodos térmicos: almacenamiento = inyección − disipación.
- RMS triaxial frente a senoidales analíticas y eliminación de componente DC.
- Respuesta independiente a lubricación, contaminación, desalineación, desequilibrio, holgura y defecto impuesto.
- Inercia térmica, enfriamiento y localidad: motor caliente y bomba refrigerada por agua.
- Válvula/NPSH, desaceleración y telemetría con motor apagado.
- Resolución de sonda, saturación explícita y rechazo de parámetros inválidos/no finitos.
- Contrato con origen simulado, unidades, hora con zona y separación de reloj físico / publicación / muestreo.
- Pausa, pérdida de señal y caducidad sin lectura anterior presentada como actual.
- Persistencia de temperaturas, ajustes, secuencia e historial; al reiniciar se desactiva la salida HTTP.
- Rechazo de duplicados y secuencias fuera de orden en SQLite.
- Envío genérico voluntario con receptor real en un puerto temporal, un intento por paquete y desconexión.
- Rechazo de destinos externos y continuidad física si el receptor no está disponible.
- Inicio HTTP local, recursos locales, ausencia de importaciones de neiron, protecciones de Host/Origin, JSON inválido, historial/CSV y flujo SSE con estado de pérdida de señal.

La comprobación de balance térmico detectó una distribución incompleta de las pérdidas normales. Se corrigió para repartir los 32 W nominales de rodamientos desde el total de pérdidas del motor, sin inyectar calor adicional. Se repitieron las pruebas con éxito. Los resultados normales finales se documentan en MODELO.md.

## Aplicación real y navegador

No se verificó solo por pruebas unitarias: se inició `python -m twin.server` como proceso real y se abrió en **Microsoft Edge** mediante Playwright. Se ejecutó el recorrido con una copia portátil que contenía **solo `twin/`**, sin neiron, sin estilos prestados, sin receptor de inicio y sin sus módulos en el proceso. SQLite de ensayo se ubicó bajo `.test-artifacts/run-...`, separado de datos operativos.

Comando de desarrollo:

```powershell
node tests\browser.cjs
```

El script usa el Playwright ya disponible en el entorno de desarrollo y Edge local. Si lo reproduces en otra PC, configura `TWIN_PLAYWRIGHT` con la ubicación del paquete de desarrollo y `TWIN_EDGE` con el ejecutable; **no son dependencias de uso de la app**.

Recorrido ejecutado:

1. Inicio autónomo, generación continua, cuatro zonas, valores, parámetros y gráficos visibles.
2. Selección por tarjeta y teclado en los puntos de la planta SVG.
3. Desalineación: RMS elevado, texto y animación `shake` en DE/acoplamiento.
4. Ensayo térmico 60×: ventilación/lubricación reducidas y contaminación; halo rojo de DE, vibración simultánea y bomba más fría. Inspección de opacidad/animación CSS y captura de pantalla.
5. Recuperación normal: conservación del calor, RMS normal y enfriamiento posterior.
6. Ajustes de agua, válvula y NPSH; cavitación localizada en bomba.
7. Pérdida de señal: `—` y 503 en lectura actual, evolución física continua; recuperación con adquisición nueva.
8. Pausa/reanudación; motor apagado/encendido con desaceleración y sensores activos.
9. Receptor de ejemplo iniciado manualmente: permanece sin datos hasta activar salida; POST aceptado, duplicado 409 e inválido 400. Desconexión sin detener planta.
10. CSV descargado con todas las zonas, fechas UTC, unidades y origen.
11. Cierre y reinicio reales: retención de parámetros, secuencia, historial y tiempo físico; valores retirados durante cierre; salida HTTP vuelve desactivada.
12. Pantalla de 390 px sin desbordamiento, respeto de movimiento reducido, cero errores JavaScript y todas las solicitudes de la aplicación limitadas al origen local. El navegador de prueba bloqueó destinos externos.

Se corrigió una comprobación de la válvula que consultaba el paquete anterior inmediatamente después de guardar el ajuste: ahora espera la adquisición nueva. La API no altera retroactivamente un paquete ya adquirido.

Informe automático y capturas se conservan localmente bajo `.test-artifacts/browser/` (excluido de Git): `report.json`, `01-planta.png`, `02-calor-vibracion.png`, `03-movil.png`, `04-escritorio.png` y `telemetria.csv`. Las bases y procesos de ensayo se cierran al concluir. También se ejecutó `INICIAR_SIMULADOR_INDEPENDIENTE.bat --no-browser` en el puerto predeterminado 8766 con datos temporales: inició solo Motor / Lab, salida desactivada, IA/hardware desactivados. La revisión final después de formatear CSS/JavaScript comprobó valores, escenario de desalineación, movimiento, recuperación y vista móvil; se cerró con Ctrl+C y confirmación de lote de Windows.

## Límites de lo verificado

No se conectó ESP32/MPU6050/DS18B20, no se calibró un motor/bomba reales, no se validaron frecuencias de daño de un rodamiento ni umbrales normativos. No se realizó una prueba de semanas de duración, suspensión prolongada del PC, todos los navegadores ni una desconexión física de internet del sistema operativo; sí se verificó que la aplicación utiliza recursos locales, no realiza solicitudes externas y mantiene IA desactivada.

La entrega es un simulador de laboratorio independiente, probado y editable. Integración física y diagnóstico quedan para otra etapa.

## Corrección de apertura · 2 de octubre de 2026

Se comprobó que los archivos y Python estaban disponibles y que no había un servicio activo en el puerto normal. Se corrigió el inicio con `twin/launcher.py`: comprueba disponibilidad de la página antes de abrirla, reconoce esta aplicación por `application_id` y reutiliza una instancia existente. Se agregaron los accesos nativos `ABRIR MOTOR LAB.lnk` / `CERRAR MOTOR LAB.lnk` y archivos de cierre, sin cambiar asociaciones ni instalar programas.

Una navegación al documento principal desde un enlace de otro origen ahora puede abrir la página. Los accesos a la API desde otro origen siguen bloqueados. Se silencian únicamente desconexiones normales del navegador para evitar trazas de error al cerrar pestañas.

**23 pruebas aprobadas** tras la corrección, incluidas apertura por enlace y cierre del servicio. Se ejecutó el `.bat` corregido en un puerto de prueba, se abrió de nuevo confirmando que reutiliza la instancia y se cerró mediante el nuevo archivo. Edge comprobó una navegación real desde `localhost` a `127.0.0.1` con cabecera `Sec-Fetch-Site: cross-site`: cuatro zonas, lecturas actuales y cero errores JavaScript. Evidencia en `.test-artifacts/apertura-informe.json` y `apertura.png`.

Al concluir esta corrección se dejó el simulador **activo en 127.0.0.1:8766**, con salida HTTP desactivada y datos normales en `%LOCALAPPDATA%\MotorPumpTwin`, y se ejecutó el acceso directo para abrir el navegador predeterminado. El archivo de cierre permite detenerlo y guardar sin depender de una consola visible.

## Vista mecánica translúcida · 2 de octubre de 2026

Se ejecutaron nuevamente las **23 pruebas automáticas** del modelo, contrato, persistencia, recepción/salida HTTP, CSV, SSE y lanzador: todas aprobadas. El modelo numérico y el contrato no se alteraron por esta mejora.

Se inició una copia independiente con base temporal y Edge real, usando `node tests/browser.cjs`. Pasaron las **15 comprobaciones del recorrido completo**: cuatro zonas, controles, calor/vibración, recuperación, agua/NPSH, pérdida de señal, pausa/apagado, receptor opcional, inválidos/duplicados, desconexión, CSV, reinicio/persistencia y vista móvil sin dependencias externas. Se conservaron reporte y capturas en `.test-artifacts/browser`.

Se añadió y ejecutó `node tests/mechanics.cjs`, con otro proceso y base temporal. Pasaron **10 comprobaciones de la nueva vista**:

1. Carcasa translúcida por defecto, cuatro zonas y siete componentes explorables.
2. Rotor y bolas con posiciones cambiantes, proyectados sobre el eje horizontal; estator fijo.
3. Acercamiento, selección de piezas y teclado sincronizados con canales de sensor; foco dentro de la pieza.
4. Opacidad regulable y alternancia exterior/interior sin modificar parámetros físicos.
5. Localización de las ocho causas: lubricación, contaminación, defecto, desalineación, desequilibrio, holgura, ventilación y cavitación. La cavitación no activa la marca de defecto del rodamiento.
6. Temperatura DE superior a 75 °C por ensayo térmico acelerado, halo rojo del detalle e interior y vibración local.
7. Pérdida de señal: lecturas y efectos actuales retirados, giro detenido y sin paquete anterior presentado como actual.
8. Pausa/reanudación y señal restaurada con adquisiciones nuevas.
9. Normal conserva calor residual; movimiento reducido congela rotor, bolas, ventilador y líneas animadas.
10. Pantalla de 390 px sin desbordamiento; cero errores JavaScript y cero solicitudes externas.

Evidencia de esta revisión: `.test-artifacts/mechanics/report.json`, `01-conjunto.png`, `02-interior.png`, `03-exterior.png`, `04-anomalias.png`, `05-movil.png` y `06-movil-vista.png`. Las capturas de escritorio y móvil se inspeccionaron visualmente y se corrigió el foco para evitar un rectángulo que ocultaba el interior. Las bases temporales se eliminan después de cerrar los procesos de ensayo; no se usan datos operativos para provocar las anomalías.

Finalmente se inició el lanzador habitual en **127.0.0.1:8766**, abrió el navegador predeterminado y se revisó también esa instancia en Edge: lecturas actuales, siete componentes, vista translúcida y cero errores. Evidencia en `inicio-local.json` y `07-aplicacion-local.png`. El servicio queda activo con los ajustes/historial conservados en `%LOCALAPPDATA%\MotorPumpTwin`; los controles del usuario pueden seguir modificando su ensayo. No se instalaron dependencias, se conectó hardware ni se publicó contenido. La localización interna continúa siendo ilustrativa de las causas impuestas, pendiente de geometría y validación del equipo real.
