@echo off
setlocal
set "PYTHONUTF8=1"
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Falta el entorno Python. Abra instalar.bat.
    pause
    exit /b 1
)
.venv\Scripts\python.exe -m twin.launcher --stop %*
if errorlevel 1 pause
