# Modelo físico reducido y límites

Motor azul inspirado en la imagen aportada, acoplamiento flexible y bomba centrífuga para agua limpia. La vista SVG tiene aspecto de gemelo virtual y responde al estado del modelo. **No es un gemelo digital calibrado**: no tiene realimentación de un equipo real. No se identifica fabricante ni modelo del motor fotografiado a partir de su apariencia.

## Referencia nominal y operación normal

Referencia eléctrica de catálogo: monofásico, dos polos, 50 Hz, 230 V, 3,7 kW / 5 HP, ~2.910 rpm y rendimiento nominal 85 %. Se emplea como hipótesis de partida, no como lectura de placa. La velocidad síncrona es 3.000 rpm; el deslizamiento simplificado responde a la carga. La potencia eléctrica se calcula para consistencia energética, sin simular arranque con capacitor, corriente, circuito eléctrico, protección ni variador.

Agua de densidad supuesta 1.000 kg/m³, sin sólidos. Circuito ilustrado recirculante con temperatura del depósito **mantenida externamente** al ajuste de agua: no simula el calentamiento acumulado del depósito ni calcula pérdidas de cada tubería. No hay un plano de instalación dimensionado.

| Magnitud | Aproximación normal con ajustes por defecto y tras estabilizar |
| --- | --- |
| Ambiente / agua | 22 / 20 °C |
| Giro | 2.912 rpm |
| Caudal / altura | 18,0 m³/h / 45,1 m |
| Potencia hidráulica / absorbida por bomba | 2,21 / 3,58 kW |
| Potencia eléctrica / carga | 4,20 kW / 96,6 % de 3,7 kW |
| Carcasa | ~52 °C |
| Rodamientos DE y NDE | ~39 °C de superficie modelada |
| Bomba | ~24 °C |
| RMS de aceleración DE / NDE / carcasa / bomba | ~0,73 / 0,58 / 0,52 / 0,43 m/s² |

Estas temperaturas y vibraciones son resultados del modelo con sus constantes, **no valores estándar universales ni límites de aceptación industrial**. Al abrir arranca desde ambiente, por lo que tardan en estabilizar. El montaje, sensor, banda de frecuencias, máquina y carga reales pueden producir cifras distintas. Ninguna referencia ISO de velocidad en mm/s se aplica a estos indicadores de aceleración.

## Hidráulica

Para velocidad relativa `r = rpm / 2910` y apertura relativa `v = valve_pct / 100`:

```text
H_bomba = 65 r² - 20 (Q/18)²        [m]
H_circuito = (45/v²) (Q/18)²        [m]
Q = 18 r sqrt(65 / (20 + 45/v²))    [m³/h]
P_agua = rho g (Q/3600) H           [W]
P_eje_bomba = P_agua / eta + 120 r³  [W]
eta = max(0,38; 0,64 exp(-0,7 (Q_rel/r - 1)²))
```

Curvas elegidas para un punto nominal de 18 m³/h y 45 m, compatibles con el motor supuesto. No se tomó la curva de una bomba concreta. El efecto de válvula sigue su intersección con la curva del circuito; cerrar parcialmente no impone automáticamente sobrecarga al motor.

NPSH requerido supuesto constante 2,5 m. El campo `suction_margin_m` de la API representa **NPSH disponible supuesto**, no diferencia respecto del requerido. Si baja de 2,5 m, un índice ilustrativo de cavitación reduce caudal hasta 25 %, altura hasta 20 % y añade ruido principalmente en la bomba. No calcula presión de vapor, altura de instalación, recirculación real ni margen NPSH normativo. No permite válvula totalmente cerrada ni simulación de marcha en seco en esta entrega.

## Térmica y causas editables

Cuatro nodos térmicos: carcasa, DE, NDE y bomba. Integración en subpasos físicos de hasta 1 s:

```text
C_i dT_i/dt = calor_i + intercambios entre nodos - disipación al entorno
```

Capacidades elegidas: carcasa 16.000 J/K, DE 2.400 J/K, NDE 1.800 J/K y bomba 6.000 J/K. Acoplamiento carcasa–rodamiento 2 W/K por lado; disipación de cada rodamiento 2,5 W/K. Refrigeración del motor depende del giro y del porcentaje disponible, con conductancia nominal ~18,18 W/K. La bomba disipa hacia agua a temperatura controlada, con conductancia `35 + 18 Q` W/K. Las sondas tienen retraso de contacto de 8 s y cuantización térmica 1/16 °C, inspirada en resolución de DS18B20 a 12 bits; no emulan su protocolo.

Las pérdidas del motor dependen de la carga. Fricción adicional de rodamientos:

```text
P_friccion = [140 (1-lubricacion)² + 75 contaminacion
              + 85 (desalineacion/1,5)² + 65 defecto] (rpm/2910)  [W]
```

Lubricación, contaminación y defecto son índices entre 0 y 1 derivados de los deslizadores. Coeficientes de escenario elegidos para probar la respuesta, no ajustados por SKF ni un fabricante. La fricción se distribuye 65 % en DE y 35 % en NDE; 32 W nominales proporcionales al giro del total de pérdidas del motor se reparten por igual entre los rodamientos y el resto se inyecta en carcasa. El intercambio interno conserva energía y la prueba térmica comprueba que energía almacenada = inyectada − disipada. La bomba recibe la diferencia entre potencia de eje y potencia del agua. Temperaturas en la sonda se limitan a -55/125 °C y marcan saturación; el estado físico interno no se confunde con el valor limitado.

Cambiar parámetros nunca sustituye instantáneamente la temperatura. Restaurar condiciones normales reduce el calor y ruido generados, conserva el calor presente y muestra recuperación térmica. **No acumula desgaste irreparable, no pronostica vida útil ni calcula probabilidad de falla**. El deslizador de defecto impone una intensidad de señal, no un porcentaje de daño medido. Se pueden combinar condiciones.

## Vibración sintética y visualización

Genera 1.000 puntos por eje en una ventana de 1 s, para cada zona. Componentes ilustrativas:

- 1× giro: desequilibrio; crece con el momento excéntrico en g·mm y con giro².
- 2× giro: efecto supuesto de desalineación.
- 3× giro: holgura de fijación.
- 6× giro: seis álabes de impulsor supuestos.
- 100 Hz: pequeña componente eléctrica a dos veces la red de 50 Hz.
- Ruido: lubricación insuficiente, contaminación y cavitación, con distinta ponderación por zona.
- Impulsos: componente a **4,7× giro supuesta** para el defecto manual. Sin geometría de rodamiento; no es una frecuencia BPFO/BPFI calculada ni un diagnóstico de pista o elemento rodante.

Se resta la media de cada eje. `RMS_vector = sqrt(RMS_X² + RMS_Y² + RMS_Z²)` en **m/s²**, excluyendo gravedad/DC. El gráfico X/Y/Z muestra los primeros 120 ms de la ventana completa. Las pruebas comparan el RMS con la solución analítica de senoidales y comprueban rechazo de un desplazamiento DC.

Con 60× se acelera solo la evolución térmica/mecánica. La señal sigue siendo una ventana sintética de 1 s a la velocidad instantánea, sin intentar representar una rampa de 60 segundos dentro de esa ventana. No se procesa un flujo real de MPU6050, no se garantiza una banda útil de ese sensor ni se simulan sus filtros, ruido electrónico y sincronización.

La representación roja comienza gradualmente al subir temperatura y resalta calor elevado. Los textos comparan con 75 °C y 3 m/s², **umbrales de demostración**. El movimiento es una amplificación visual limitada y el impulsor gira a una velocidad de dibujo legible. No es una escala de desplazamiento, una medición óptica ni una representación exacta del giro real. Se desactiva con movimiento reducido.

## Representación interna · revisión visual del 2 de octubre de 2026

La vista SVG usa una disposición genérica de motor de inducción: estator fijo con núcleo laminado y cabezas de bobina, rotor de jaula sobre un eje horizontal, apoyos DE/NDE y ventilador posterior. La carcasa de aletas cambia de opaca a translúcida sin modificar la física. Se representan ocho bolas por rodamiento, solo como geometría de dibujo; no se conocen fabricante, dimensiones, pistas, número de bolas ni contacto del rodamiento de la foto. El detalle ampliado usa la misma cantidad ilustrativa. No se reproduce el circuito eléctrico, los devanados exactos, condensadores ni un interruptor de arranque.

`twin/static/mechanics.js` genera las capas, materiales e interacciones; `mechanics.css` define presentación y preferencias de movimiento. El código Python sigue siendo responsable de señales, reloj, almacenamiento y salida a receptores. La animación no genera telemetría ni crea canales nuevos. Los recursos son locales y no necesitan Blender, WebGL, modelos descargados ni librerías de terceros.

El giro se proyecta sobre el eje horizontal: varían las posiciones de barras, álabes y bolas, sin girar en el plano de la pantalla el cuerpo lateral del rotor. A velocidad nominal se dibujan aproximadamente 0,55 vueltas por segundo; la jaula visual usa 0,4 de esa velocidad, una decisión de dibujo que no calcula cinemática de un rodamiento real. La masa excéntrica y la vibración se amplifican para verse. El estator permanece fijo salvo la vibración del conjunto.

Las marcas de fricción, contaminación y defecto se muestran en los apoyos; la desalineación en DE/transmisión, el desequilibrio en rotor/apoyos, la holgura en fijaciones y la reducción de aire en la ventilación. La cavitación permanece en la bomba. **La localización deriva del parámetro impuesto, no de un diagnóstico de la señal RMS.** Una marca roja sobre una pista solo identifica un contacto ilustrativo; no afirma BPFO/BPFI ni ubica un daño real. Los halos térmicos utilizan los cuatro canales superficiales existentes, no temperaturas internas de bobinas, pistas o bolas. Al faltar un paquete actual se ocultan los efectos y se congela el giro, conservando el estado físico del backend. El movimiento reducido congela también rotor, bolas y ventilador.

## Fuentes primarias consultadas

- [WEG · W22 Single Phase, mercado europeo](https://static.weg.net/medias/downloadcenter/h52/h99/WEG-w22-single-phase-european-market-50069268-brochure-english-web.pdf): referencia nominal y disposición general de piezas; no identificación ni reconstrucción exacta de la foto.
- [Hydraulic Institute · Pump Curves](https://datatool.pumps.org/pump-fundamentals/pump-curves.html): relación de caudal, altura, potencia, rendimiento y NPSH; curvas y constantes de esta app son hipótesis propias.
- [SKF · Bearing damage and failure analysis](https://cdn.skfmediahub.skf.com/api/public/093168a92d25cc46/pdf_preview_medium/14219_3_EN_-_Bearing_failures_LOW_pdf_preview_medium.pdf): mecanismos cualitativos de lubricación, contaminación y daños; no prescribe los índices, frecuencias ni coeficientes sintéticos aquí usados.
- [Analog Devices · DS18B20](https://www.analog.com/media/en/technical-documentation/data-sheets/DS18B20.pdf): rango/resolución de referencia para sonda virtual; adquisición física pendiente.

Las fuentes son documentación, no llamadas externas del programa. Su lectura no implica certificación, recomendación de umbrales ni calibración. Para el equipo real faltan placa, curva, rodamientos, puntos de sensor, montaje y ensayos controlados.
